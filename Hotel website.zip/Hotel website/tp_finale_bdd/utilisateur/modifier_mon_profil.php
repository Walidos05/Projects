﻿<?php
$user=$_GET["user"];
mysql_connect ("localhost","root","");
mysql_select_db("gestionconf");
$result= mysql_query("SELECT * FROM users WHERE (username='$user')");
$nb = mysql_numrows($result);
$line = mysql_fetch_assoc($result);
$gestion="<p><strong>Gestion des sessions</strong></p>
		<a class='style1' href='/tp_finale_bdd/session/ajout_session.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'>
		</a><br>
		<a class='style1' href='/tp_finale_bdd/session/liste_session.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>
		    <p><strong>Gestion des tutoriels</strong></p>
		<a class='style1' href='/tp_finale_bdd/tutoriel/ajout_tutoriel.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		 <input type='button' class='button1' value='Ajouter'>
		</a><br>
	    <a class='style1' href='/tp_finale_bdd/tutoriel/liste_tutoriel.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
		</a><br>
			  <p><strong>Gérer les papiers</strong></p>
			   <a class='style1' href='/tp_finale_bdd/papier/ajout_papier.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'>
		</a><br>
		<a class='style1' href='/tp_finale_bdd/papier/liste_papier.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>
			  <p><strong>Gestion des utilisateurs</strong></p>
		<a class='style1' href='/tp_finale_bdd/utilisateur/liste.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>";

?>

<html>
<head>
<title>Page d'Accueil</title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

.Style1 {color: #FF0000}
.Style4 {font-size: 24px}
.button1 { border:hidden; background-image:url(/tp_finale_bdd/img/button.png); width:85; height:20}
</style>

</head>
<body style="background-image:url(/tp_finale_bdd/img/shadow.jpg); background-size:cover">
<p>
<table cellspacing="0" cellpadding="8" width="1010" align="center" border="0">
<tr>
<td width="142" valign="top"><table width="142" height="252" border="0">
  <tr bgcolor="#CCCCCC">
    <td width="136" height="30"><marquee>
      vous avez &eacute;galement le droit de faire
      </marquee></td>
  </tr>
  <tr valign="top" bgcolor="#CCCCCC">
    <td height="700" align="center"><?php
    echo"$gestion";
	?></td>
  </tr>
</table></td>
<td width="670">
<table cellspacing="0" cellpadding="8" width="670" align="center" border="0">
  <tr>
    <td height="191" background="/tp_finale_bdd/img/1rasmus-conference-big2.jpg">
      <h1 align="center"><br>
        <img src="/tp_finale_bdd/img/nd.jpg" height="63" width="63">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#ffffff">Modifier mon profil</font></h1></td>
  </tr>
  <tr>
        <td background="/tp_finale_bdd/img/shadow1.bmp">
        <center>
		<?php 
			echo"
			<a href='/tp_finale_bdd/session/liste_session.php?user=$line[username]&voir=1'>
			 <span class='Style1'>
			  <img src='/tp_finale_bdd/img/rech.png'>
			  <input type='button' class='button1' value='Mes sessions'>
			 </span>
			</a>&nbsp;&nbsp;&nbsp;&nbsp;
			<a href='/tp_finale_bdd/tutoriel/liste_tutoriel.php?user=$line[username]&voir=1'>
			 <span class='Style1'>
			  <img src='/tp_finale_bdd/img/rech.png'>
			  <input type='button' class='button1' value='Mes tutoriels'>
			 </span>
			</a>&nbsp;&nbsp;&nbsp;&nbsp;
			<a href='/tp_finale_bdd/papier/liste_papier.php?user=$line[username]&voir=1'>
			 <span class='Style1'>
			  <img src='/tp_finale_bdd/img/rech.png'>
			  <input type='button' class='button1' value='Mes papiers'>
			 </span>
			</a>";
		?>
        </center>
        </td>
  </tr>
  <tr>
    <td height="480" valign="top" style="background-image:url(/tp_finale_bdd/img/bg.png)">
      <p align="center"><font color="#000000" size="6">Modifier mon profil</font></p>
      <p align="center">&nbsp;</p>
      <p align="left">
        <?php
      if(isset($_GET["inscrit"])){
         $firstname=$_POST["firstname"];
         $lastname=$_POST["lastname"];
         $organisation=$_POST["organisation"];
         $adress=$_POST["adress"];
         $city=$_POST["city"];
         $country=$_POST["country"];
         $category=$_POST["category"];
         $telephone=$_POST["telephone"];
         $username=$_POST["username"];
         $password=$_POST["password"];
if(($username!=null)and($password!=null)and($firstname!=null)and($lastname!=null)and($organisation!=null)and($adress!=null)and($city!=null)and($country!=null)and($category!=null)){
         $query="'$username','$password','$firstname','$lastname','$organisation','$adress','$city','$country','$category','$telephone'";
         mysql_connect ("localhost","root","");
         mysql_select_db("gestionconf");
         $result= mysql_query("UPDATE users SET (username='$username', password='$password', firstname='$firstname', lastname='$lastname', organisation='$organisation', adress='$adress', city='$city', country='$country', category='$category', telephone='$telephone') WHERE username='$user'");
         echo"<br> <h3><strong>votre profil a &eacute;t&eacute; modifi&eacute; avec succ&eacute;.</strong></h3>";
}else{echo"<br> <h3><strong>AAAH!!,Nous nous-excusons, vous avez oublier un (des) champ(s) obligatoire(s).<br>veuillez cliquez <a href='inscrire.php'><strong> ici pour réessayer.</strong></a></strong></h3>";}
      }else{
      echo"
	  <form action='inscrire.php?inscrit=1' method='post'>
       <p align='center'><div align='center' style=\"background-color:#666; color:#FFF; text-height:80;\">veuillez remplir le formulaire ci-dessous les champs avec &eacute;toile (*) sont obligatoire.</div></strong></p>
        <table align='center' border=0>
	     <tr><td align='right'>* Nom:</td><td align='left' id='1'><input name='firstname'></td></tr>
	     <tr><td align='right'>* Pr&eacute;nom:</td><td align='left' id='2'><input name='lastname'></td></tr>
	     <tr><td align='right'>* Organisation:</td><td align='left' id='3'><input name='organisation'></td></tr>
	     <tr><td align='right'>* adresse:</td><td align='left' id='4'><input name='adress'></td></tr>
	     <tr><td align='right'>* cité:</td><td align='left' id='5'><input name='city'></td></tr>
	     <tr><td align='right'>* Pay:</td><td align='left' id='6'><input name='country'><input name='category' type='hidden' value='1'></td></tr>
	     <tr><td align='right'>N=° TEL:</td><td align='left' id='7'><input name='telephone'></td></tr>
	     <tr><td align='right'>* Username(Login):</td><td align='left' id='8'><input name='username'></td></tr>
	     <tr><td align='right'>* mot de passe:</td><td align='left' id='9'><input type='password' name='password'></td></tr>
	    </table>
       <p align='center'><input class='button1' type='submit' value='Envoyer'></p>
      </form>";};

      ?>
      </p>
      <p>  </p></td></tr>
  <tr>
  <td BGCOLOR=#333333></td>
  </tr>
</table>
</td>
<td width="150" valign="top"><table>
  <tr bgcolor="#CCCCCC">
    <td><marquee direction="up" >
      <div align="center">
        <p class="Style1">----------------------------- <span class="Style4">Bienvenue</span></p>
        <p class="Style1">
          <?php if(isset($line))echo"$line[firstname] $line[lastname]"; ?>
          &nbsp; </p>
        <p class="Style1">-----------------------------</p>
        <p class="Style1">chez le guide du gestion des conf&eacute;rences.</p>
        <p class="Style1">----------------------------- </p>
      </div>
    </marquee></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td height="530" align="center" valign="top"><?php
	  if(isset($user)){
		  echo"
		       <p><h3>Action sur votre profil</h3></p>
			    <span class='Style1'>
			     <form action='/tp_finale_bdd/login.php?log=1' method='post'>
				  <input type='hidden' name='login' value='$line[username]'>
				  <input type='hidden' name='password' value='$line[password]'>
				  <input type='submit' class='button1' value='Accueil'>
				 </form>
				 <input type='button' class='button1' value='Modifier'><img src='/tp_finale_bdd/img/vous_etes_ici.jpg'>
			     
			    </span>
		  ";
	  }
	 ?></td>
  </tr>
</table></td>
</tr>
</table>
</p>
<p>&nbsp;</p>
</body>
</html>