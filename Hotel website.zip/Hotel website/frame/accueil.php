<html>
<body background="D.jpg" >
<a href="accueil.php"target="content"><br/></a></td></tr>
</body>
</html>