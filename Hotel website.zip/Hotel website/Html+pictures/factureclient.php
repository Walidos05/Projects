<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionclient") or die("ne peut pas selectionner la base indiqu�e");
?>

<?php
$c=$_POST["f"];
$query = "SELECT * FROM facture where code =$c ";
$result = mysql_query($query) or die("requette echou�e");
?>
<html>
<body>
<style type="text/css">
html, body {margin:0; padding:0; width:100%; height:100%; overflow:hidden; text-align:left;}
body {font-family: 'Tinos', serif;}
#background{position:absolute; z-index:1; width:100%; height:100%;}
#fixed {position:absolute; top:25px; left:10px; width:160px; z-index:10; color:#333; padding:10px;}
#scroller {position:absolute; width:100%; height:100%; top:5; left:5; overflow:auto; z-index:3;} 
#content {padding:20px 20px 20px 200px;}
p {font-size:16px; text-align:justify; line-height:25px; text-shadow: 0 1px 2px rgba(0,0,0,0.5), 0px -1px 2px rgba(255,255,255,0.8);}
h1 {font-family: 'Salsa', cursive; font-size:50px; color:#248; padding-left:20%; text-shadow: 0 5px 10px rgba(0,0,0,0.5), 0px -5px 10px rgba(255,255,255,0.8);}
h2 {font-family: 'Salsa', cursive; font-size:40px; color:#248; padding-left:1.5%; text-shadow: 0 4px 8px rgba(0,0,0,0.5), 0px -4px 8px rgba(255,255,255,0.8);}
h3 {font-family: 'Salsa', cursive; font-size:30px; color:#248; padding-left:1.5%; text-shadow: 0 3px 6px rgba(0,0,0,0.5), 0px -3px 6px rgba(255,255,255,0.8);}
h4 {font-family: 'Salsa', cursive; font-size:25px; color:#369; padding-left:1.5%; text-shadow: 0 2px 4px rgba(0,0,0,0.5), 0px -2px 4px rgba(255,255,255,0.8);}
.Col {width:25%; float:left; padding:2%; min-width:300px;}
</style>
</head>
<body>
<div>
	<img id="background" src="fa.jpg" alt="" title="" /> 
</div>
<div id="scroller">
<div id="content">
<div id="fixed">
<b>LISTE DES facture:</b><br><br>
<table border=\"1\">
<tr bgcolor='cyan'>
    	<td><b>idfact</b></td> 
    	<td><b>datefact</b></td>
      <td><b>code</b></td>
</tr>

<?php
//Afficher tous les utilisateurs
while ($line = mysql_fetch_assoc($result)) {//renvoie un tableau dont les cl�s sont les noms des champs s�lectionn�s.
      echo "<tr>";
      echo "<td>$line[idfact]</td>";
      echo "<td>$line[datefact]</td>";
echo "<td>$line[code]</td>";
	    echo "</tr>";
}
echo "</table>";
?>
<br><br><ol><ol><ol><font face="Times New Roman"size="14"><a href='facture.php'>Retour.au.menu</a>
</body>
</html>