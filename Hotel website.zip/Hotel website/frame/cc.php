
<html><head>
<style type="text/css">
body {
	font-family:verdana,arial,sans-serif;
	font-size:10pt;
	margin:10px;
	background-color:#000;
	}
</style>
</head>
<body>
<!-- Begin Free-Web-Buttons.com -->
<style>#web-buttons-idqtxf1 a{display:block;color:transparent;} #web-buttons-idqtxf1 a:hover{background-position:left bottom;}a#web-buttons-idqtxf1a {display:none}</style>
<table id="web-buttons-idqtxf1" width=0 cellpadding=0 cellspacing=0 border=0>
<tr><td style="padding-bottom:14px" title ="commit� membre">
<a href="listecommiteesession.php" title="commit� membre" style="background-image:url(comit�-files/btqtxf1.png);width:151px;height:34px;display:block;" target="content"><br/></a></td></tr>
<tr><td style="padding-bottom:14px" title ="commit� local">
<a href="reservationhotels.php" title="commit� local" style="background-image:url(comit�-files/btmtxf1.png);width:151px;height:34px;display:block;" target="content"><br/></a></td></tr>
</table><a id="web-buttons-idqtxf1a" href="http://free-web-buttons.com">Button To A Webpage by Free-Web-Buttons.com v2.0</a>
<!-- End Free-Web-Buttons.com -->
</body></html>
