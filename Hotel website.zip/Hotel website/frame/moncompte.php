<html>

<form method="post" action="suitecompte.php">
<b>Remplir les information suivante:</b><br>
<br>
<li>USERNAME:<input type="text" name="username" size="30"><br>
<li>PASSWORD:<input type="text" name="password" size="30"><br>
<input type="Submit" value="Envoyer">
<input type="Reset"  value="Initialiser">
</form>

</html>
