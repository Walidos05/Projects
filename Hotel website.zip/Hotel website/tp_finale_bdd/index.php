<html>
<head>
<title>Page d'Accueil</title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

.Style1 {color: #FF0000}
.Style4 {font-size: 24px}
.button { border:hidden; background-color:#00F; color:#FFF; width:85; height:25 }
.button1 { border:hidden; background-image:url(/tp_finale_bdd/img/button.png); width:85; height:20}
.input { border-bottom:#FFF; background-color:#E4E4E4; height:25}
</style>

</head>
<body style="background-image:url(img/shadow.jpg); background-size:cover" >
      <?php
      $connect=mysql_connect("localhost","root","")or die("Impossible de se connecter � MySQL.");
      $result =mysql_query("CREATE DATABASE gestionconf");
      $selection= mysql_select_db("gestionconf");
      $result1 = mysql_query("create table users(
                                     username varchar(25) NOT NULL PRIMARY KEY,
                                     password varchar(25) NOT NULL,
                                     firstname varchar(25) NOT NULL,
                                     lastname varchar(25) NOT NULL,
                                     organisation varchar(25) NOT NULL,
                                     adress varchar(35) NOT NULL,
                                     city varchar(25) NOT NULL,
                                     country varchar(25) NOT NULL,
                                     category char(1) NOT NULL,
                                     telephone varchar(28))");
      $result2 = mysql_query("create table registrations (
                                     username varchar(25) NOT NULL,
                                     category char(1) NOT NULL,
                                     hotel int,
                                     jour1 int,
                                     jour2 int,
                                     jour3 int,
                                     jour4 int,
                                     jour5 int,
                                     jour6 int,
                                     tour int,
                                     total int,
                                     payed varchar(20),
                                     PRIMARY KEY (username))");
      $result3 = mysql_query("create table tutor_regis (
                                     tutorial_id int UNSIGNED NOT NULL,
                                     username varchar(25) NOT NULL,
                                     PRIMARY KEY (tutorial_id,username))");
      $result4 = mysql_query("create table sessions (
                                     session_id int UNSIGNED AUTO_INCREMENT UNIQUE NOT NULL,
                                     sessionname_fr varchar(25) NOT NULL,
                                     sessionname_en varchar(25) NOT NULL,
                                     PRIMARY KEY (session_id))");
      $result5 = mysql_query("create table tutorials(
                                     tutorial_id int UNSIGNED AUTO_INCREMENT UNIQUE NOT NULL,
                                     title varchar(255) NOT NULL,
                                     author varchar(255),
                                     datetutor date NOT NULL,
                                     timetutor time NOT NULL,
                                     PRIMARY KEY (tutorial_id))");
      $result6 = mysql_query("create table responsables(
                                     username varchar(25) NOT NULL,
                                     session_id int UNSIGNED NOT NULL,
									 PRIMARY KEY (username,session_id))");
      $result7 = mysql_query("create table comite_session (
                                     username varchar(255) NOT NULL,
                                     session_id int UNSIGNED NOT NULL,
                                     PRIMARY KEY (username,session_id))");
      $result8 = mysql_query("create table papers (
                                     paper_id int UNSIGNED AUTO_INCREMENT NOT NULL,
                                     titre varchar(255) NOT NULL,
                                     date_fait date NOT NULL,
                                     abstract text,
									 url varchar(255),
                                     langue varchar(15) NOT NULL,
                                     PRIMARY KEY (paper_id))");
      $result9 = mysql_query("create table author_paper (
                                     username varchar(255) NOT NULL,
                                     paper_id int UNSIGNED NOT NULL,
                                     PRIMARY KEY (username,paper_id))");
      $result10= mysql_query("create table comite_paper (
                                     username varchar(255) NOT NULL,
                                     paper_id int UNSIGNED NOT NULL,
                                     clarity int,
                                     soundness int,
                                     inventivity int,
                                     acceptance int,
                                     PRIMARY KEY (username, paper_id))");
      $result11= mysql_query("create table paper_session (
                                     paper_id int UNSIGNED NOT NULL,
                                     session_id int UNSIGNED NOT NULL,
                                     PRIMARY KEY (paper_id, session_id))");
      $result12= mysql_query("create table hotels (
                                     hotel_id int UNSIGNED AUTO_INCREMENT UNIQUE NOT NULL,
                                     name varchar(255) NOT NULL,
                                     price int NOT NULL,
                                     PRIMARY KEY (hotel_id))");
	  $add_admin=mysql_query("INSERT INTO users VALUES ('admin','admin','BENHAMIDA','Abdallah','2 SI, GUELMA','Bouchegouf-GUELMA','Bouchegouf','ALGERIE',1,'0000000000')");
	  $add_hotel=mysql_query("INSERT INTO hotels(name,price) VALUES ('mermoura',5000)");
	?>
<p>
<table cellspacing="0" cellpadding="8" width="970" align="center" border="0">
<tr id="tr1">
<td valign="top" width="150" id="td1"><table width="150" height="350" border="0">
  <tr>
    <td height="123" bgcolor="#CCCCCC"><marquee direction="up">
      <div align="center">
        <p class="Style1">----------------------------- <span class="Style4">Bienvenue</span></p>
        <p class="Style1">-----------------------------</p>
        <p class="Style1">chez le guide du gestion des conf&eacute;rences.</p>
        <p class="Style1">----------------------------- </p>
      </div>
    </marquee></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC" height="600"></td>
  </tr>
</table></td>
<td width="670">
<table cellspacing="0" cellpadding="8" width="670" align="center" border="0">
  <tr>
    <td width="641" height="200" BACKGROUND="img/copie-_2_-de-fotolia_10430113_s.jpg">
      <h1 align="center"><br><img src="img/home.png" height="30" width="30">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#ffffff">Page d'Accueil</font></h1></td></tr>
  <tr>
        <td style="background-image:url(/tp_finale_bdd/img/shadow1.bmp)" align="right">
        <p>
        <a href="/tp_finale_bdd/index.php"><input type="button" class="button1" value="Index"></a>
        <a href="/tp_finale_bdd/session/liste_session.php?voir=2"><input type="button" class="button1" value="Les Sessions"></a>
        <a href="/tp_finale_bdd/tutoriel/liste_tutoriel.php?voir=2"><input type="button" class="button1" value="Les tutoriels"></a>
        <a href="/tp_finale_bdd/papier/liste_papier.php?voir=2"><input type="button" class="button1" value="Les Papiers"></a>
        <a href="/tp_finale_bdd/inscrire.php"><input type="button" class="button1" value="S'inscrire"></a>
        <input type="button" class="button1" value="Connecter" onClick="lab2.hidden=1-lab2.hidden">
        <img src="img/down.png" onClick="lab2.hidden=1-lab2.hidden">
        <form id="ifr1" action="/tp_finale_bdd/login.php" method="post">
        <table align="center" border="0" id="lab2" style="visibility:visible; background-color: #838383; position:absolute; width: 236px; height: 85px;" hidden="1" name="lab2">
        <tr><td></td><td align="right"><img src="img/close.png" onClick="lab2.hidden=1"></td></tr>
        <tr><td width="116" align="left">Login</td><td width="140"><input class="input" id="log" title="Username" name='login'></td></tr>
        <tr><td align="left">Password</td><td><input class="input" id="pwd" type="password" title="Mot de Passe" name='password'></td></tr>
        <tr><td></td><td align="right"><input class="button1" title="Connecter" value="Connecter" type="submit"></td></tr>
        </table>
        </form>
        </p></td>
  </tr>
  <tr style="background-image:url(img/bg.png)">
    <td height="510" valign="top">
      <p align="center"><font color="#000000" size="6">Bienvenu</font></p>
      <p align="left">
<?php
      if($result){
        echo"La base est cr�� avec succ�s.<br>Tout les tables de la base sont cr��s.<br>";
      }
      else echo"<center><h3>chez le site de gestion des conf�rences.</h3></center><br><br>";
      ?>
      si vous avez un compte d�ja, veuillez ouvrir votre compte.</p>
      <p align="left">ou bien vous pouvez:</p>

      <ul style="MARGIN-RIGHT: 0px" dir="ltr">
        <li>
      <div align="left"><p><a href="/tp_finale_bdd/inscrire.php"><img src="/tp_finale_bdd/img/nd.jpg" height="20" width="20">&nbsp;S'inscrire.</a></p></div></li>
        <li>
        <div align="left"><p><a href="/tp_finale_bdd/session/liste_session.php?voir=2"><img src='/tp_finale_bdd/img/rech.png'>Liste des sessions.</a></p></div>
        </li>
        <li>
        <div align="left"><p><a href="/tp_finale_bdd/papier/liste_papier.php?voir=2"><img src='/tp_finale_bdd/img/rech.png'>Liste des papiers.</a></p></div>
        </li>
        <li>
        <div align="left"><p><a href="/tp_finale_bdd/tutoriel/liste_tutoriel.php?voir=2"><img src='/tp_finale_bdd/img/rech.png'>Liste des tutoriels.</a></p></div>
        </li>
      </ul></td></tr>
  <tr bgcolor="#333333">
  <td></td>
  </tr>
</table></td>
<td height="650" bgcolor="#CCCCCC"></td>
</tr>
</table>
</p>
<p>&nbsp;</p>
</body>
</html>