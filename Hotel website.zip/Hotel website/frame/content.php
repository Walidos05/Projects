<html>
<head>
<title>HTML Frames Example - Content</title>

</style>
</head>
<body background="D.jpg" >
<center>
<h1><marquee class="Scroller" behavior="scroll" direction="right" width="100%" height="19" scrollamount="2" scrolldelay="0" onmouseover="this.stop()" onmouseout="this.start()"><font size="4" face=
"Arial, Helvetica, sans-serif"><strong><em><font color="black"><sup><Q>*****************<b>SYSTEM DE GESTION DES CONFERENCES</b>*********************</Q></strong></font></marquee>
<div style="background:white;width:60%height="20""></h1>
</center>
</body>
</html>