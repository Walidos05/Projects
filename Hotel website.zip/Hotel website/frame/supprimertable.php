<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd) or die ("connexion impossible"); 

//supprimer la base de donn�es "scolarite"
$query="drop database gestionconference";
$result = mysql_query($query) or die("<p><b>requette echou�e</b><p/>");
echo"La base est supprim�e avec succ�s";

?> 
