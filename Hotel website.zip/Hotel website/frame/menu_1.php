<html>
<head>
<title>HTML Frames Example - Menu 1</title>
<style type="text/css">
body {
	font-family:verdana,arial,sans-serif;
	font-size:10pt;
	margin:10px;
	background-color:#ff9900;
	}
</style>
</head>
<body background="CIEL2.jpg">
<h3>Menu 1</h3>
<p><a href="#" target="content">White Page</a></p>

<h4>More Examples:</h4>
<a href="#" target="_top">Example 1</a><br />
<a href="#" target="_top">Example 2</a><br />
<a href="#" target="_top">Example 3</a><br />
<a href="#" target="_top">Example 4</a><br />
<a href="#" target="_top">Example 5</a><br />
</body>
</html>