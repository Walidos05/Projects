<html><head></head>
<body background="resp.jpg"><center>
<!-- Begin Free-Web-Buttons.com -->
<style>#web-buttons-id6gyi2 a{display:block;color:transparent;} #web-buttons-id6gyi2 a:hover{background-position:left bottom;}a#web-buttons-id6gyi2a {display:none}</style>
<table id="web-buttons-id6gyi2" width=0 cellpadding=0 cellspacing=0 border=0><tr>
<td style="padding-right:7px" title ="Affichage">
<a href="m2.php" title="Affichage" style="background-image:url(1-files/bt6gyi2.png);width:82px;height:26px;display:block;"><br/></a></td>
<td style="padding-right:7px" title ="modificatioon">
<a href="m3.php" title="modificatioon" style="background-image:url(1-files/bt2gyi2.png);width:107px;height:26px;display:block;"><br/></a></td>
</tr></table><a id="web-buttons-id6gyi2a" href="http://free-web-buttons.com">Button To A Webpage by Free-Web-Buttons.com v2.0</a>
</center>
<!-- End Free-Web-Buttons.com -->
</body></html>