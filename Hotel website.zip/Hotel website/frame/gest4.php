<?php
$code=$_GET['username'];
      mysql_connect ("localhost","root","");
      mysql_select_db("gestionconference");
      $result = mysql_query("DELETE FROM committee_paper WHERE username='$username'");
      echo"<br> <h3><strong> suupprim&eacute;e avec succ�s.</h3></strong>";
 
      ?>