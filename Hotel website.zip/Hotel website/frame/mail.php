<html>
<head>
<title>Formulaiure de Contact</title>
<link rel="stylesheet" type="text/css" href="styles1.css">
<script language="javascript">

function validation()
{
if(!verif(document.form.email.value)) { 
alert("Votre email est invalide !");
document.form.email.focus();
return false; 
} 
}


//fonction qui v�rifie la validiter d'un mail 
function verif(email) { // Email valide ?
var arobase = email.indexOf("@")
var point = email.lastIndexOf(".")
if((arobase < 3)||(point + 2 > email.length)
||(point < arobase+3)) return false
return true
}

</script>
</head>
<body>
<div align="center">
<table width="100%"  height="450""0">
    <tr> 
      <td height="679"> 
        <center>
           <form name="form" method="post" action="mercimail.php" onsubmit="return validation();">
             <table border="0" width="100%">
              <tr> 
                <td height="503"> 
                  <p><font size="4"><b><font color="#FF0033" size="3">*</font></b></font>Les 
                    champs marqu� d'un <font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                    sont obligatoires ...</p>
                  <p><font size="4"><b><font color="#FF0033" size="3">*</font></b></font>Tous 
                    formulaire n&eacute;tant pas renseign&eacute; correctement 
                    n'aura pas de suite ...</p>
                  <p>&nbsp;</p>
                  <table width="100%" border="0">
                    <tr> 
                      <td width="39%"> 
                        <div align="right">Nom<font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                          :</div>
                      </td>
                      <td width="61%"><b> 
                        <input name="Nom  "size=20>
                        </b></td>
                    </tr>
                    <tr> 
                      <td width="39%"> 
                        <div align="right">Pr&eacute;nom<font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                          :</div>
                      </td>
                      <td width="61%"><b> 
                        <input name="Pr&eacute;nom"size=20>
                        </b></td>
                    </tr>
                    <tr> 
                      <td width="39%"> 
                        <div align="right">Sexe<font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                          :</div>
                      </td>
                      <td width="61%"> 
                        <select class=styleselect tabindex=4 
                        name=Sexe>
                          <option value="- - - -">- - - -</option>
                          <option value="Feminin">Feminin</option>
                          <option value="Masculin">Masculin</option>
                        </select>
                      </td>
                    </tr>
                    <tr> 
                      <td width="39%"> 
                        <div align="right">Date de Naissance<font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                          :</div>
                      </td>
                      <td width="61%"><b> 
                        <select name="jour_naissance" title="Jour de naissance">
                          <option value="0">--</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                          <option value="6">6</option>
                          <option value="7">7</option>
                          <option value="8">8</option>
                          <option value="9">9</option>
                          <option value="10">10</option>
                          <option value="11">11</option>
                          <option value="12">12</option>
                          <option value="13">13</option>
                          <option value="14">14</option>
                          <option value="15">15</option>
                          <option value="16">16</option>
                          <option value="17">17</option>
                          <option value="18">18</option>
                          <option value="19">19</option>
                          <option value="20">20</option>
                          <option value="21">21</option>
                          <option value="22">22</option>
                          <option value="23">23</option>
                          <option value="24">24</option>
                          <option value="25">25</option>
                          <option value="26">26</option>
                          <option value="27">27</option>
                          <option value="28">28</option>
                          <option value="29">29</option>
                          <option value="30">30</option>
                          <option value="31">31</option>
                        </select>
                        <select name="mois_naissance" title="Mois">
                          <option value="0">--</option>
                          <option value="01">janvier</option>
                          <option value="02">fevrier</option>
                          <option value="03">mars</option>
                          <option value="04">avril</option>
                          <option value="05">mai</option>
                          <option value="06">juin</option>
                          <option value="07">juillet</option>
                          <option value="08">aout</option>
                          <option value="09">septembre</option>
                          <option value="10">octobre</option>
                          <option value="11">novembre</option>
                          <option value="12">decembre</option>
                        </select>
                        <select name="annee_naissance" title="Ann�e">
                          <option value="0" selected>--</option>
                          <option value="1994">1994</option>
                          <option value="1993">1993</option>
                          <option value="1992">1992</option>
                          <option value="1991">1991</option>
                          <option value="1990">1990</option>
                          <option value="1989">1989</option>
                          <option value="1988">1988</option>
                          <option value="1987">1987</option>
                          <option value="1986">1986</option>
                          <option value="1985">1985</option>
                          <option value="1984">1984</option>
                          <option value="1983">1983</option>
                          <option value="1982">1982</option>
                          <option value="1981">1981</option>
                          <option value="1980">1980</option>
                          <option value="1979">1979</option>
                          <option value="1978">1978</option>
                          <option value="1977">1977</option>
                          <option value="1976">1976</option>
                          <option value="1975">1975</option>
                          <option value="1974">1974</option>
                          <option value="1973">1973</option>
                          <option value="1972">1972</option>
                          <option value="1971">1971</option>
                          <option value="1970">1970</option>
                          <option value="1969">1969</option>
                          <option value="1968">1968</option>
                          <option value="1967">1967</option>
                          <option value="1966">1966</option>
                          <option value="1965">1965</option>
                          <option value="1964">1964</option>
                          <option value="1963">1963</option>
                          <option value="1962">1962</option>
                          <option value="1961">1961</option>
                          <option value="1960">1960</option>
                          <option value="1959">1959</option>
                          <option value="1958">1958</option>
                          <option value="1957">1957</option>
                          <option value="1956">1956</option>
                          <option value="1955">1955</option>
                          <option value="1954">1954</option>
                          <option value="1953">1953</option>
                          <option value="1952">1952</option>
                          <option value="1951">1951</option>
                          <option value="1950">1950</option>
                          <option value="1949">1949</option>
                          <option value="1948">1948</option>
                          <option value="1947">1947</option>
                          <option value="1946">1946</option>
                          <option value="1945">1945</option>
                          <option value="1944">1944</option>
                          <option value="1943">1943</option>
                          <option value="1942">1942</option>
                          <option value="1941">1941</option>
                          <option value="1940">1940</option>
                          <option value="1939">1939</option>
                          <option value="1938">1938</option>
                          <option value="1937">1937</option>
                          <option value="1936">1936</option>
                          <option value="1935">1935</option>
                          <option value="1934">1934</option>
                          <option value="1933">1933</option>
                          <option value="1932">1932</option>
                          <option value="1931">1931</option>
                          <option value="1930">1930</option>
                          <option value="1929">1929</option>
                          <option value="1928">1928</option>
                          <option value="1927">1927</option>
                          <option value="1926">1926</option>
                          <option value="1925">1925</option>
                          <option value="1924">1924</option>
                          <option value="1923">1923</option>
                          <option value="1922">1922</option>
                          <option value="1921">1921</option>
                          <option value="1920">1920</option>
                          <option value="1919">1919</option>
                          <option value="1918">1918</option>
                          <option value="1917">1917</option>
                          <option value="1916">1916</option>
                          <option value="1915">1915</option>
                        </select>
                        </b> </td>
                    </tr>
                    <tr> 
                      <td height="22" width="39%"> 
                        <div align="right">Pays<font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                          :</div>
                      </td>
                      <td height="22" width="61%"> 
                        <select size=1 name=Pays>
                          <option value=" " selected>S&eacute;lection pays</option>
                          <option>Allemagne</option>
                          <option>Argentine</option>
                          <option>Australie</option>
                          <option>Belgique</option>
                          <option>Br&eacute;sil</option>
                          <option>Canada</option>
                          <option>Chili</option>
                          <option>Chine</option>
                          <option>Colombie</option>
                          <option>Cor&eacute;e</option>
                          <option>Danemark</option>
                          <option>Etats Unis</option>
                          <option>Espagne</option>
                          <option>Finlande</option>
                          <option>France</option>
                          <option>Hongrie</option>
                          <option>Inde</option>
                          <option>Irlande</option>
                          <option>Israel</option>
                          <option>Italie</option>
                          <option>Japon</option>
                          <option>Mexique</option>
                          <option>Norv&egrave;ge</option>
                          <option>Nouvelle-Z&eacute;lande</option>
                          <option>Pays Bas</option>
                          <option>P&eacute;rou</option>
                          <option>Pologne</option>
                          <option>Portugal</option>
                          <option>Rep. Tch&egrave;que</option>
                          <option>Royaume Uni</option>
                          <option>Russie</option>
                          <option>Slovaquie</option>
                          <option>Slov&eacute;nie</option>
                          <option>Su&egrave;de</option>
                          <option>Suisse</option>
                          <option>Taiwan</option>
                          <option>Turquie</option>
                          <option>Uruguay</option>
                          <option>Venezuela</option>
                        </select>
                      </td>
                    </tr>
                    <tr> 
                      <td height="22" width="39%"> 
                        <div align="right">Ville :</div>
                      </td>
                      <td height="22" width="61%"><b> 
                        <input name="Ville"size=20>
                        </b> </td>
                    </tr>
                    <tr> 
                      <td width="39%"> 
                        <div align="right"> Code Postal :</div>
                      </td>
                      <td width="61%"><b> 
                        <input name="Code-Postal"size=20 maxlength=40>
                        </b></td>
                    </tr>
                    <tr> 
                      <td width="39%"> 
                        <div align="right">Adresse Mail<font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                          :</div>
                      </td>
                      <td width="61%"><b> 
                        <input type="text" name="email" size="40">
                        </b></td>
                    </tr>
                    <tr> 
                      <td width="39%"> 
                        <div align="right">Adresse de votre Site Web :</div>
                      </td>
                      <td width="61%"><b> 
                        <input name="Adresse-Site"size=40 value="http://">
                        </b></td>
                    </tr>
                    <tr> 
                      <td width="39%"> 
                        <div align="right"></div>
                      </td>
                      <td width="61%">&nbsp;</td>
                    </tr>
                  </table>
                  <p align="center">Sujet de Mail<font size="4"><b><font color="#FF0033" size="3">*</font></b></font> 
                    :<b> </b><font color="#000000"><b> 
                    <input name="Sujet-du-Mail  "size=40 maxlength=60>
                    </b></font></p>
                  <p align="center">
                    <textarea name="Message " cols="50" rows="8"></textarea>
                  </p>
                  <p align="center"><font color="#000000"> </font> </p>
                </td>
              </tr>
            </table>
            <p><b><font color="#000000"> 
              <input type="submit" value="Envoyer" name="Envoyer">
              <input type="reset" name="Submit" value="Effacer">
              </font></b> </p>
            </form>
          <p><A href="http://www.amourdeschats.be.cx/">www.conference.com</A></p>
        </center>
      </td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
</body>
</html>