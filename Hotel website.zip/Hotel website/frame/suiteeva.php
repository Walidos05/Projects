<?php
$favourable=$_POST['favourable'];
$against=$_POST['against'];
$clarity=$_POST['clarity'];
$relevance=$_POST['relevance'];
$originality=$_POST['originality'];
$acceptance=$_POST['acceptance'];

echo "bonjour<br>";
echo "l'evaluation des papiers est:<br>";
echo "<li>l'�tat favourable est: <b>$favourable</b><br>";
echo "<li>l'�tat contre est: <b>$against</b><br>";
echo "<li>la clarity est: <b>$clarity</b><br>";
echo "<li>la relevance est: <b>$relevance</b><br>";
echo "<li>l'originali� est: <b>$originality</b><br>";
echo "<li>l'acceptance est: <b>$acceptance</b><br>";

?>