<?php
$code=$_GET['tutorial_id'];
      mysql_connect ("localhost","root","");
      mysql_select_db("gestionconference");
      $result = mysql_query("DELETE FROM tutor_regis WHERE tutorial_id='$tutorial_id'");
      echo"<br> <h3><strong> suupprim&eacute;e avec succ�s.</h3></strong>";
 
      ?>