<?php
if(isset($_GET["user"])){$user=$_GET["user"];}else{$user=null;};
mysql_connect ("localhost","root","");
mysql_select_db("gestionconf");
$result= mysql_query("SELECT * FROM users WHERE (username='$user')");
$nb = mysql_num_rows($result);
$line = mysql_fetch_assoc($result);
$category=$line['category'];
$gestion="<p><strong>Gestion des sessions</strong></p>
		<a class='style1' href='/tp_finale_bdd/session/ajout_session.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'>
		</a><br>
		<a class='style1' href='/tp_finale_bdd/session/liste_session.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>
		    <p><strong>Gestion des tutoriels</strong></p>
		<a class='style1' href='/tp_finale_bdd/tutoriel/ajout_tutoriel.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		 <input type='button' class='button1' value='Ajouter'>
		</a><br>
	    <a class='style1' href='/tp_finale_bdd/tutoriel/liste_tutoriel.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
		</a><br>
			  <p><strong>G�rer les papiers</strong></p>
			   <a class='style1' href='/tp_finale_bdd/papier/ajout_papier.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'>
		</a><br>
		<a class='style1' href='/tp_finale_bdd/papier/liste_papier.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'></a>
	    <img src='/tp_finale_bdd/img/vous_etes_ici.jpg'><br>
			  <p><strong>Gestion des utilisateurs</strong></p>
		<a class='style1' href='/tp_finale_bdd/utilisateur/liste.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>";

?>
<html>
<head>
<title>Profil <?php if($line){echo"de $line[firstname] $line[lastname]";}?></title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

.Style1 {color: #FF0000}
.Style4 {font-size: 24px}
.button1 { border:hidden; background-image:url(/tp_finale_bdd/img/button.png); width:85; height:20}

</style>


</head>
<body background="/tp_finale_bdd/img/shadow.jpg" style="background-size:cover">
<p>
<table cellspacing="0" cellpadding="8" width="999" align="center" border="0">
<tr valign="top">
<td width="142">
<table width="142" height="252" border="0">
  <tr>
    <td width="136" height="30" bgcolor="#CCCCCC">vous pouvez &eacute;galement:</td>
  </tr>
  <tr valign="top" bgcolor="#CCCCCC">
    <td height="700" align="center"><?php
    if(isset($line)&&$line)echo"$gestion";
	?></td>
  </tr>
</table>
</td>
<td width="659" valign="top">
 <table cellspacing="0" cellpadding="8" width="651" align="left" border="0">
  <tr>
    <td width="635" height="200" BACKGROUND="/tp_finale_bdd/img/copie-_2_-de-fotolia_10430113_s.jpg">
      <h1 align="center"><br>
        <img src="/tp_finale_bdd/img/home.png" height="42" width="42">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#ffffff">Consulter une Papier</font></h1>
    </td>
   </tr>
  <tr>
   <td background="/tp_finale_bdd/img/shadow1.bmp">
    <p>&nbsp;</p>
   </td>
  </tr>
  <tr>
   <td height="480" valign="top" style="background-image:url(/tp_finale_bdd/img/bg.png)">
    <p align="center">
     <font color="#000000" size="6">
     Consulter Papier
     </font>
    </p>
    <p align="left">
     <center>
      
      <?php
	  if(isset($_GET["ajout�"])){
		  $code=$_GET['code'];
		  $clarity=$_POST['clarity'];
		  $soundness=$_POST['soundness'];
		  $inventivity=$_POST['inventivity'];
		  $acceptance=$_POST['acceptance'];
		  
	  $result1=mysql_query("INSERT INTO comite_paper VALUES ('$user','$code','$clarity','$soundness','$inventivity','$acceptance')");
	  if($result1){echo"<br><h3><strong>votre avis a &eacute;t&eacute; ajout&eacute;e avec succ&eacute;.<br>Merci &agrave; poser votre avis.</h3></strong>";}
	  else{echo"<br><h3><strong>D�sol�, une faute est survenue pendant l'ajout de votre avis.<br>Peut &ecirc;tre que vous avez d&eacute;ja poser votre avis.</h3></strong>";}
	  }
	  else{
	  $code=$_GET['code'];
echo"<h3><strong><div align='center' style=\"background-color:#666; color:#FFF; text-height:80;\">Voici le papier:.</div></strong></h3>";
 $result1 = mysql_query("SELECT *
                         FROM papers p,author_paper ap,users u
			             where ap.username=u.username and
			                   p.paper_id=ap.paper_id and
							   p.paper_id='$code'");
  while ($line1 = mysql_fetch_assoc($result1)) {
        echo "<table>
		                       <tr><td>Titre:</td><td>$line1[titre]</td></tr>
							   <tr><td>Date:</td><td>$line1[date_fait]</td></tr>
							   <tr><td>Langue:</td><td>$line1[langue]</td></tr>
							   <tr><td>r&eacute;sum&eacute;:</td><td>$line1[abstract]</td></tr>
							   <tr><td>Auteur:</td><td>";
								 if($line['username']==$line1['username']){echo"vous meme";}else{echo"$line1[firstname]&nbsp;$line1[lastname]";};
								 $download=$line1['url'];
							   echo"</td></tr>
							   <tr><td>T&eacute;l&eacute;charger le document:</td><td><a href='$download'><img src='/tp_finale_bdd/img/add.png'>veuillez cliquez ici</a></td></tr>

							   </table>";}
echo"<h3><strong>&Eacute;valuation g&eacute;n&eacute;rale du papier:</strong></h3>";
$res=mysql_query("SELECT SUM(clarity)/count(*)
                  FROM comite_paper
				  WHERE paper_id='$code'")or die(mysql_error());
	while ($lin = mysql_fetch_assoc($res)) {
		$r=array_shift($lin);
		echo "<strong>clarit&eacute; :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>".$r."<br>";/*array_shift : permet de prendre un �l�ment du tableau.*/
	}
$res1=mysql_query("SELECT SUM(soundness)/count(*)
                  FROM comite_paper
				  WHERE paper_id='$code'")or die(mysql_error());
	while ($lin1 = mysql_fetch_assoc($res1)) {
		$r1=array_shift($lin1);
		echo "<strong>Solidit&eacute; :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>".$r1."<br>";
	}
$res2=mysql_query("SELECT SUM(inventivity)/count(*)
                  FROM comite_paper
				  WHERE paper_id='$code'")or die(mysql_error());
	while ($lin2 = mysql_fetch_assoc($res2)) {
		$r2=array_shift($lin2);
		echo "<strong>inventivit&eacute; :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>".$r2."<br>";
	}
$res3=mysql_query("SELECT SUM(acceptance)/count(*)
                  FROM comite_paper
				  WHERE paper_id='$code'")or die(mysql_error());
	while ($lin3 = mysql_fetch_assoc($res3)) {
		$r3=array_shift($lin3);
		echo "<strong>acceptance :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>".$r3."<br>";
	}
if(($r+$r1+$r2+$r3)>=15){
	if($category==1){
	echo"<a href='/tp_finale_bdd/utilisateur/reserver.php?user=$user&code=$line1[username]'><input type='button' class='button1' value='r�server'></a>";
	}
}

if($user!=null){
echo"<form action='/tp_finale_bdd/papier/consulter_papier.php?ajout&eacute;=1&user=$user&code=$code' method='post'>
     <p align='center'><h3><strong><div align='center' style=\"background-color:#666; color:#FFF; text-height:80;\">veuillez donner votre avis sur ce doccument.</div></strong></h3></p>
 <center>
 <table>
 <tr><td>clarit&eacute;</td><td><select name='clarity'>
                                 <option value=1>1</option>
								 <option value=2>2</option>
								 <option value=3>3</option>
								 <option value=4>4</option>
								 <option value=5>5</option>
                                </select></td></tr>
 <tr><td>Solidit&eacute;</td><td><select name='soundness'>
                                 <option value=1>1</option>
								 <option value=2>2</option>
								 <option value=3>3</option>
								 <option value=4>4</option>
								 <option value=5>5</option>
                                </select></td></tr>
 <tr><td>inventivit&eacute;</td><td><select name='inventivity'>
                                 <option value=1>1</option>
								 <option value=2>2</option>
								 <option value=3>3</option>
								 <option value=4>4</option>
								 <option value=5>5</option>
                                </select></td></tr>
 <tr><td>acceptance&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><select name='acceptance'>
                                 <option value=1>1</option>
								 <option value=2>2</option>
								 <option value=3>3</option>
								 <option value=4>4</option>
								 <option value=5>5</option>
                                </select></td></tr>
 </table>
 <input class='button1' type='submit' value='Ajouter'>
 </center>

     </form>";

}
	  }
?>
      
     </center>
    </p>
    <p></p>
   </td>
  </tr>
 </table>
</td>
<td width="150"><table>
  <tr bgcolor="#CCCCCC">
    <td><marquee direction="up" >
      <div align="center">
        <p class="Style1">----------------------------- <span class="Style4">Bienvenue</span></p>
        <p class="Style1">
          <?php if(isset($line))echo"$line[firstname] $line[lastname]"; ?>
          &nbsp; </p>
        <p class="Style1">-----------------------------</p>
        <p class="Style1">chez le guide du gestion des conf&eacute;rences.</p>
        <p class="Style1">----------------------------- </p>
      </div>
    </marquee></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td height="530" align="center" valign="top"><?php
	  if(isset($user)){
		  echo"
		       <p><h3>Action sur votre profil</h3></p>
			    <span class='Style1'>
			     <form action='/tp_finale_bdd/login.php?log=1' method='post'>
				  <input type='hidden' name='login' value='$line[username]'>
				  <input type='hidden' name='password' value='$line[password]'>
				  <input type='submit' class='button1' value='Accueil'>
				 </form>
				 <a href='/tp_finale_bdd/utilisateur/modifier_mon_profil.php?user=$line[username]'><input type='button' class='button1' value='Modifier'></a>
			     
			    </span>
		  ";
	  }
	 ?></td>
  </tr>
</table></td>
</tr>
</table>
</p>
<p>&nbsp;</p>
</body>
</html>