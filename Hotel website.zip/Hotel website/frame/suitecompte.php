<html>
<form method="post" action="suitecomp.php">
<li>MON TEXT:<br>
  <textarea name="commentaire" cols="50"></textarea>
<hr>
<input type="Submit" value="Envoyer">
<input type="Reset"  value="Initialiser">
</form>
</html>