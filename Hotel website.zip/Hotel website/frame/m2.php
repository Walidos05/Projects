<html><head></head>
<body background="bgg.jpg"><center>
<!-- Begin Free-Web-Buttons.com -->
<style>#web-buttons-idoptfs a{display:block;color:transparent;} #web-buttons-idoptfs a:hover{background-position:left bottom;}a#web-buttons-idoptfsa {display:none}</style>
<table id="web-buttons-idoptfs" width=0 cellpadding=0 cellspacing=0 border=0><tr>
<td style="padding-right:7px" title ="les papiers de la session">
<a href="listepapersession.php" title="les papiers de la session" style="background-image:url(m2-files/btoptfs.png);width:188px;height:34px;display:block;"><br/></a></td>
<td style="padding-right:7px" title =" les evaluations des papiers">
<a href="evaluation.php" title=" les evaluation des papiers" style="background-image:url(m2-files/btwptfs.png);width:188px;height:34px;display:block;"><br/></a></td>
<td style="padding-right:7px" title ="l'etat des papiers">
<a href="#" title="l'etat des papiers" style="background-image:url(m2-files/bt4ptfs.png);width:188px;height:34px;display:block;"><br/></a></td>

</tr></table><a id="web-buttons-idoptfsa" href="http://free-web-buttons.com">Button To A Webpage by Free-Web-Buttons.com v2.0</a></center>
<!-- End Free-Web-Buttons.com -->
</body></html>