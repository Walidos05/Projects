<html>
<head>
<link rel="stylesheet" type="text/css" href="styles1.css">
</head>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>. . . . . : : : : : Votre message a bien �t� envoy�. Merci ! : : : : : . 
    . . . .</p>
  <p><span class='txtform'>. . . . . : : : : : Nous allons y donner suite dans 
    les meilleurs d�lais. : : : : : . . . . .<br>
    </span></p>
  <p>&nbsp;</p>
  <p><a href="mail.php"><span class='txtform'>. . . . . : : : : :</span> Fermer 
    : : : : : . . . . .</a></p>
</div>
</html>