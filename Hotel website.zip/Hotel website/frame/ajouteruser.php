<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "ajouteruser.php?insertuser=1">
<table border="1" width="403">
    <p>formulaire d'ajout d'un utilisateur </p>

    <tr>
      <td width="141" bgcolor='4407FA'>username</td>
      <td width="312"><input type="text" name="username"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Password</td>
      <td width="312"><input type="text" name="password"></td>
    </tr>
    <tr>
    <tr>
      <td width="141" bgcolor='4407FA'>first name</td>
      <td width="312"><input type="text" name="firstname"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>last name</td>
      <td width="312"><input type="text" name="lastname"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Organisation</td>
      <td width="312"><input type="text" name="organisation"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Address</td>
      <td width="312"><input type="text" name="address"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>City</td>
      <td width="312"><input type="text" name="city"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Telephone</td>
      <td width="312"><input type="text" name="telephone"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Country</td>
      <td width="312"><input type="text" name="country"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Category</td>
      <td width="312"><input type="text" name="category"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Job</td>
      <td width="312"><input type="text" name="job"></td>
    </tr>
      
<?php

$insertuser =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['insertuser'])){
      $u=$_POST['username'];
	  $p=$_POST['password'];
      $f=$_POST['firstname'];
      $l=$_POST['lastname'];
      $o=$_POST['organisation'];  
	  $a=$_POST['adress'];
	  $c=$_POST['city'];
	  $t=$_POST['telephone'];
	  $co=$_POST['country'];
	  $ca=$_POST['category'];
	  $j=$_POST['job'];
	  
  //insertion de tuples
      $query="INSERT INTO users VALUES ('$u','$p','$f','$l','$o','$a','$c','$t','$co','$ca','$j')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>Utilisateur ajout� avec succ�s";
      }
else{};
?>
