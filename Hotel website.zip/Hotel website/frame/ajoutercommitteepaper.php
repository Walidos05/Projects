<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "ajoutercommitteepaper.php?insertcommitteepaper=1">
<table border="1" width="403">
    <p>formulaire d'ajout d'une committee paper</p>

    <tr>
      <td width="141" bgcolor='4407FA'>Username</td>
      <td width="312"><input type="text" name="username"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Paper id</td>
      <td width="312"><input type="text" name="paper_id"></td>
    </tr>
    <tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Summary</td>
      <td width="312"><input type="text" name="summary"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Comment</td>
      <td width="312"><input type="text" name="comment"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Favourable</td>
      <td width="312"><input type="text" name="favourable"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Against</td>
      <td width="312"><input type="text" name="against"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Clarity</td>
      <td width="312"><input type="text" name="clarity"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Relevance</td>
      <td width="312"><input type="text" name="relevance"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Originality</td>
      <td width="312"><input type="text" name="originality"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Acceptance</td>
      <td width="312"><input type="text" name="acceptance"></td>
    </tr>
      
<?php

$insertcommitteepaper =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['insertcommitteepaper'])){
      $u=$_POST['username'];
	  $p=$_POST['paper_id'];
      $s=$_POST['summary'];
      $c=$_POST['comment'];
      $f=$_POST['favourable'];  
	  $a=$_POST['against'];
	  $cl=$_POST['clarity'];
	  $r=$_POST['relevance'];
	  $o=$_POST['originality'];
	  $ac=$_POST['acceptance'];
	  	  
  //insertion de tuples
      $query="INSERT INTO committee_paper VALUES ('$u','$p','$s','$c','$f','$a','$cl','$r','$o','$ac')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>Utilisateur ajout� avec succ�s";
      }
else{};
?>
