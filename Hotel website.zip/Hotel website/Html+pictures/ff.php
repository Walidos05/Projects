<?php 
    sesssion_start(); 
    if(!$_SESSION['islogged']){ 
        header("Location: /login.php"); 
        exit; 
    } 
?> 
<html> 
<head> 
    <title>Users Page</title> 
</head> 
<body> 
    <?php 
        echo '<h1>Welcome '.$_SESSION['user'].'!</h1>'; 
    ?> 
    <p> 
        You are now viewing the members page,  
        if you did not login in correctly, 
        then you would not be seeing this page display. 
    </p> 
</body> 
</html>