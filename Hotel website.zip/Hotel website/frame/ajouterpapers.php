<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "ajouterpapers.php?insertpapers=1">
<table border="1" width="403">
    <p>formulaire d'ajout d'un papers </p>

    <tr>
      <td width="141" bgcolor='4407FA'>Paper id</td>
      <td width="312"><input type="text" name="paper_id"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Title</td>
      <td width="312"><input type="text" name="title"></td>
    </tr>
    <tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Date</td>
      <td width="312"><input type="text" name="date"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Keyword</td>
      <td width="312"><input type="text" name="keyword"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Abstract</td>
      <td width="312"><input type="text" name="abstract"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Language</td>
      <td width="312"><input type="text" name="language"></td>
    </tr>
	
      
<?php

$insertpapers =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['insertpapers'])){
      $p=$_POST['paper_id'];
	  $t=$_POST['title'];
      $d=$_POST['date'];
      $k=$_POST['keyword'];
      $a=$_POST['abstract'];  
	  $l=$_POST['language'];
	  	  
  //insertion de tuples
      $query="INSERT INTO papers VALUES ('$p','$t','$d','$k','$a','$l')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>Utilisateur ajout� avec succ�s";
      }
else{};
?>
