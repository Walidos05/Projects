<html>
<form method="post" action="suiteeva.php">
<b>Evaluation des papiers:</b><br>
<li>FAVOURABLE:<br>
  <textarea name="favourable" cols="50"></textarea>
<li>AGAINST:<br>
  <textarea name="against" cols="50"></textarea>
<li>CLARITY: <select name="clarity">
<option selected>1<option>2<option>3<option>4<option>5
</select><br>
<li>RELEVANCE: <select name="relevance">
<option selected>1<option>2<option>3<option>4<option>5
</select><br>
<li>ORIGINALITY: <select name="originality">
<option selected>1<option>2<option>3<option>4<option>5
</select><br>
<li>ACCEPTANCE: <select name="acceptance">
<option selected>1<option>2<option>3<option>4<option>5
</select><br>
<hr>
<input type="Submit" value="Envoyer">
<input type="Reset"  value="Initialiser">
</form>

</html>