<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "ajouterregistrations.php?insertregistrations=1">
<table border="1" width="403">
    <p>formulaire d'ajout d'une registrations</p>

    <tr>
      <td width="141" bgcolor='4407FA'>Username</td>
      <td width="312"><input type="text" name="username"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Category</td>
      <td width="312"><input type="text" name="category"></td>
    </tr>
    <tr>
    <tr>
      <td width="141" bgcolor='4407FA'>hotel id</td>
      <td width="312"><input type="text" name="hotel_id"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Days</td>
      <td width="312"><input type="text" name="days"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Total cost</td>
      <td width="312"><input type="text" name="totalcost"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Paid</td>
      <td width="312"><input type="text" name="paid"></td>
    </tr>
	
      
<?php

$insertregistrations =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['insertregistrations'])){
      $u=$_POST['username'];
	  $c=$_POST['category'];
      $h=$_POST['hotel_id'];
      $d=$_POST['days'];
      $t=$_POST['totalcost'];  
	  $p=$_POST['paid'];
	  	  
  //insertion de tuples
      $query="INSERT INTO registrations VALUES ('$u','$c','$h','$d','$t','$p')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>Utilisateur ajout� avec succ�s";
      }
else{};
?>
