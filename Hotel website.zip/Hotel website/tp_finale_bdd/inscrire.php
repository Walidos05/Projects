<html>
<head>
<title>Page d'Accueil</title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

.Style1 {color: #FF0000}
.Style4 {font-size: 24px}
.button1 { border:hidden; background-image:url(/tp_finale_bdd/img/button.png); width:85; height:20}
</style>

</head>
<body style="background-image:url(/tp_finale_bdd/img/shadow.jpg); background-size:cover">
<p>
<table cellspacing="0" cellpadding="8" width="970" align="center" border="0">
<tr>
<td width="150" valign="top"><table width="150" height="350" border="0">
  <tr>
    <td height="123" bgcolor="#CCCCCC"><marquee direction="up" >
      <div align="center">
        <p class="Style1">----------------------------- <span class="Style4">Bienvenue</span></p>
        <p class="Style1">-----------------------------</p>
        <p class="Style1">chez le guide du gestion des conf&eacute;rences.</p>
        <p class="Style1">----------------------------- </p>
      </div>
    </marquee></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td height="600">&nbsp;</td>
  </tr>
</table></td>
<td width="670">
<table cellspacing="0" cellpadding="8" width="670" align="center" border="0">
  <tr>
    <td height="191" background="img/1rasmus-conference-big2.jpg">
      <h1 align="center"><br>
        <img src="img/nd.jpg" height="63" width="63">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#ffffff">Inscription</font></h1></td>
  </tr>
  <tr>
        <td background="/tp_finale_bdd/img/shadow1.bmp">
         <form action="login.php" method="post">
          <p align="right">
           <a href="/tp_finale_bdd/index.php"><input type="button" class="button1" value="Index"></a>
        <a href="/tp_finale_bdd/session/liste_session.php?voir=2"><input type="button" class="button1" value="Les Sessions"></a>
        <a href="#">
        <input type="button" class="button1" value="Connecter" onClick="lab2.hidden=1-lab2.hidden">
        <form onMouseOut="top.height='0'" data- id="ifr1" action="/tp_finale_bdd/login.php" method="post">
        <table width="272" border="0" id="lab2" style="visibility: visible; background-color: #838383; position: absolute; left: 619px; top: 247px; width: 236px; height: 85px;" hidden="1" name="lab2">
        <tr><td width="116" align="left">Login</td><td width="140"><input id="log" title="Username" name='login'></td></tr>
        <tr><td align="left">Password</td><td><input id="pwd" type="password" title="Mot de Passe" name='password'></td></tr>
        <tr><td></td><td align="right"><input class="button1" title="Connecter" value="Connecter" type="submit"></td></tr>
        </table>
        </form>
        </p>
         </form></td>
  </tr>
  <tr>
    <td height="510" valign="top" style="background-image:url(img/bg.png)">
      <p align="center"><font color="#000000" size="6">Inscription</font></p>
      <p align="center">&nbsp;</p>
      <p align="left">
        <?php
      if(isset($_GET["inscrit"])){
         $firstname=$_POST["firstname"];
         $lastname=$_POST["lastname"];
         $organisation=$_POST["organisation"];
         $adress=$_POST["adress"];
         $city=$_POST["city"];
         $country=$_POST["country"];
         $category=$_POST["category"];
         $telephone=$_POST["telephone"];
         $username=$_POST["username"];
         $password=$_POST["password"];
if(($username!=null)and($password!=null)and($firstname!=null)and($lastname!=null)and($organisation!=null)and($adress!=null)and($city!=null)and($country!=null)and($category!=null)){
         $query="'$username','$password','$firstname','$lastname','$organisation','$adress','$city','$country','$category','$telephone'";
         mysql_connect ("localhost","root","");
         mysql_select_db("gestionconf");
         $result= mysql_query("INSERT INTO users VALUES($query)");
         echo"<br> <h3><strong>utilisateur ajout&eacute; avec succ&eacute;.</strong></h3>";
}else{echo"<br> <h3><strong>AAAH!!,Nous nous-excusons, vous avez oublier un (des) champ(s) obligatoire(s).<br>veuillez cliquez <a href='inscrire.php'><strong> ici pour r�essayer.</strong></a></strong></h3>";}
      }else{
      echo"
	  <form action='inscrire.php?inscrit=1' method='post'>
       <p align='center'>veuillez remplir le formulaire ci-dessous<br>les champs avec &eacute;toile (*) sont obligatoire.</p>
        <table align='center' border=0>
	     <tr><td align='right'>* Nom:</td><td align='left' id='1'><input name='firstname'></td></tr>
	     <tr><td align='right'>* Pr&eacute;nom:</td><td align='left' id='2'><input name='lastname'></td></tr>
	     <tr><td align='right'>* Organisation:</td><td align='left' id='3'><input name='organisation'></td></tr>
	     <tr><td align='right'>* adresse:</td><td align='left' id='4'><input name='adress'></td></tr>
	     <tr><td align='right'>* cit�:</td><td align='left' id='5'><input name='city'></td></tr>
	     <tr><td align='right'>* Pay:</td><td align='left' id='6'><input name='country'><input name='category' type='hidden' value='5'></td></tr>
	     <tr><td align='right'>N=� TEL:</td><td align='left' id='7'><input name='telephone'></td></tr>
	     <tr><td align='right'>* Username(Login):</td><td align='left' id='8'><input name='username'></td></tr>
	     <tr><td align='right'>* mot de passe:</td><td align='left' id='9'><input type='password' name='password'></td></tr>
	    </table>
       <p align='center'><input class='button1' type='submit' value='Envoyer'></p>
      </form>";};

      ?>
      </p>
      <p>  </p></td></tr>
  <tr>
  <td BGCOLOR=#333333></td>
  </tr>
</table>
</td>
<td width="150" height="650" bgcolor="#CCCCCC"></td>
</tr>
</table>
</p>
<p>&nbsp;</p>
</body>
</html>