import React from "react";

function NotFound() {
  return (
    <div className="container p-4">
      <h2>NotFound</h2>
    </div>
  );
}

export default NotFound;
