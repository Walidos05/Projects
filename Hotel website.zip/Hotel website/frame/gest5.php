<?php
$code=$_GET['hotel_id'];
      mysql_connect ("localhost","root","");
      mysql_select_db("gestionconference");
      $result = mysql_query("DELETE FROM hotels WHERE hotel_id='$hotel_id'");
      echo"<br> <h3><strong> suupprim&eacute;e avec succ�s.</h3></strong>";
 
      ?>