<html>
<body>
<style type="text/css">
html, body {margin:0; padding:0; width:100%; height:100%; overflow:hidden; text-align:left;}
body {font-family: 'Tinos', serif;}
#background{position:absolute; z-index:1; width:100%; height:100%;}
#fixed {position:absolute; top:25px; left:10px; width:160px; z-index:10; color:#333; padding:10px;}
#scroller {position:absolute; width:100%; height:100%; top:5; left:5; overflow:auto; z-index:3;} 
#content {padding:20px 20px 20px 200px;}
p {font-size:16px; text-align:justify; line-height:25px; text-shadow: 0 1px 2px rgba(0,0,0,0.5), 0px -1px 2px rgba(255,255,255,0.8);}
h1 {font-family: 'Salsa', cursive; font-size:50px; color:#248; padding-left:20%; text-shadow: 0 5px 10px rgba(0,0,0,0.5), 0px -5px 10px rgba(255,255,255,0.8);}
h2 {font-family: 'Salsa', cursive; font-size:40px; color:#248; padding-left:1.5%; text-shadow: 0 4px 8px rgba(0,0,0,0.5), 0px -4px 8px rgba(255,255,255,0.8);}
h3 {font-family: 'Salsa', cursive; font-size:30px; color:#248; padding-left:1.5%; text-shadow: 0 3px 6px rgba(0,0,0,0.5), 0px -3px 6px rgba(255,255,255,0.8);}
h4 {font-family: 'Salsa', cursive; font-size:25px; color:#369; padding-left:1.5%; text-shadow: 0 2px 4px rgba(0,0,0,0.5), 0px -2px 4px rgba(255,255,255,0.8);}
.Col {width:25%; float:left; padding:2%; min-width:300px;}
</style>
</head>
<body>
<div>
	<img id="background" src="abir.jpg" alt="" title="" /> 
</div>
<div id="scroller">
<div id="content">
<div id="fixed">
<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionclient") or die("ne peut pas selectionner la base indiqu�e");
?>
<h2 align='center'><font face=Times New Roman size=6 color=blue>
<form method="post" action= "ajouterclient.php?insertclient=1">
<table align="center" border="2" style="background-color : white">
    <p>formulaire.d'ajout.d'un.client </p>

    <tr>
      <td width="141" bgcolor='yellow'>Code</td>
      <td width="312"><input type="text" name="code"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='yellow'>Nom</td>
      <td width="312"><input type="text" name="nom"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='yellow'>Pr�nom</td>
      <td width="312"><input type="text" name="prenom"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='yellow'>adress</td>
      <td width="312"><input type="text" name="adress"></td>
    </tr>
    <tr>
      <td width="141" bgcolor='yellow'>numpiece</td>
      <td width="312"><input type="text" name="numpiece"></td>
      </tr>
<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />

    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['insertclient'])){
      $c=$_POST['code'];
      $n=$_POST['nom'];
      $p=$_POST['prenom'];
      $d=$_POST['adress'];
      $v=$_POST['numpiece'];      
      //insertion de tuples
      $query="INSERT INTO client VALUES ('$c','$n','$p','$d','$v')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>client.ajout�.avec.succ�s";
      }
else{};
?></Form>
<a href='client.php'>Retour.au.menu</a>
	
</body>
</html>