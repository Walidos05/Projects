﻿<?php
$user=$_GET["user"];
mysql_connect ("localhost","root","");
mysql_select_db("gestionconf");
$result= mysql_query("SELECT * FROM users WHERE username='$user'");
$nb = mysql_numrows($result);
$line = mysql_fetch_assoc($result);
$gestion="<p><strong>Gestion des sessions</strong></p>
		<a class='style1' href='/tp_finale_bdd/session/ajout_session.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'>
		</a><br>
		<a class='style1' href='/tp_finale_bdd/session/liste_session.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><img src='/tp_finale_bdd/img/vous_etes_ici.jpg'><br>
		    <p><strong>Gestion des tutoriels</strong></p>
		<a class='style1' href='/tp_finale_bdd/tutoriel/ajout_tutoriel.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		 <input type='button' class='button1' value='Ajouter'>
		</a><br>
	    <a class='style1' href='/tp_finale_bdd/tutoriel/liste_tutoriel.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
		</a><br>
			  <p><strong>Gérer les papiers</strong></p>
			   <a class='style1' href='/tp_finale_bdd/papier/ajout_papier.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'>
		</a><br>
		<a class='style1' href='/tp_finale_bdd/papier/liste_papier.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>
			  <p><strong>Gestion des utilisateurs</strong></p>
		<a class='style1' href='/tp_finale_bdd/utilisateur/liste.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>";

?>
<html>
<head>
<title>Profil <?php if($line){echo"de $line[firstname] $line[lastname]";}?></title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

.Style1 {color: #FF0000}
.Style4 {font-size: 24px}
.button1 { border:hidden; background-image:url(/tp_finale_bdd/img/button.png); width:85; height:20}

</style>
</head>
<body background="/tp_finale_bdd/img/shadow.jpg" style="background-size:cover">
<p>
<table cellspacing="0" cellpadding="8" width="999" align="center" border="0">
<tr valign="top">
<td width="142"><table width="142" height="252" border="0">
  <tr>
    <td width="136" height="30" bgcolor="#CCCCCC">vous pouvez &eacute;galement:</td>
  </tr>
  <tr valign="top" bgcolor="#CCCCCC">
    <td height="700" align="center"><?php
    echo"$gestion";
	?></td>
  </tr>
</table></td>
<td width="659" valign="top">
<table cellspacing="0" cellpadding="8" width="651" align="left" border="0">
  <tr>
    <td width="635" height="200" BACKGROUND="/tp_finale_bdd/img/copie-_2_-de-fotolia_10430113_s.jpg">
      <h1 align="center"><br>
        <img src="/tp_finale_bdd/img/home.png" height="42" width="42">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#ffffff">Modifier une session</font></h1></td></tr>
  <tr>
        <td background="/tp_finale_bdd/img/shadow1.bmp">
        <p>&nbsp;</p>
        </td>
  </tr>
  <tr>
    <td height="480" valign="top" style="background-image:url(/tp_finale_bdd/img/bg.png)" id="temp">
      <p align="center"><font color="#000000" size="6">Modifier une session</font></p>
      <p align="left">
<?php
$code=$_GET['code'];
if(isset($_GET["modifié"])){
$nb=$_POST['nb'];
$result  = mysql_query("UPDATE sessions SET sessionname_fr='$_POST[fr]',sessionname_en='$_POST[en]' WHERE session_id='$code'");

$result1 = mysql_query("UPDATE responsables SET username='$_POST[resp]' WHERE session_id='$code'");

$result2 = mysql_query("DELETE FROM comite_session WHERE session_id='$code'");
for($i=1;$i<=$nb;$i++){
	$user=$_POST["check$i"];
	mysql_query("INSERT INTO comite_session VALUES ('$user','$code')");
}

if($result && $result1 && $result2){echo"<br><h3><strong>session modifi&eacute;e avec succ&eacute;.</h3></strong>";}
else{echo"Désolé, une faute est survenue pendant l'ajout du session.";};

}else{
echo"<form action='modifier_session.php?modifié=1&user=$user&code=$code' method='post'>
 <p align='center'><div align='center' style=\"background-color:#666; color:#FFF; text-height:80;\">veuillez remplir le formulaire ci-dessous les champs avec &eacute;toile (*) sont obligatoire.</div></strong></p>
 <center>
 <table>
 <tr><td>nom session en français</td><td><input name='fr'></td</tr>
 <tr><td>nom session en anglais</td><td><input name='en'></td</tr>
 <tr><td>* responsable (username)</td>
     <td>
	  <select name='resp'>
	   <option value='none'></option>";
$select=mysql_query("select * from users");
while($line=mysql_fetch_assoc($select)){
	echo"<option value='$line[username]'>$line[firstname]&nbsp;$line[lastname]</option>";
}
echo"	  </select>
	 </td>
 </tr>
 <tr><td>* commitée</td>
     <td>";
$i=1;
$select=mysql_query("select * from users");
$nb=mysql_num_rows($result);
while($line=mysql_fetch_assoc($select)){
	echo"<input type='checkbox' name='check$i' value='$line[username]'>$line[firstname]&nbsp;$line[lastname]";
	$i=$i+1;
}
echo"	 </td>
 </tr>
 
 </table>
 <input name='nb' type='hidden' value='$nb'>
 <input class='button1' type='submit' value='Modifier'>
 </center>
</form>";};
?>
</p>
      <p>  </p></td></tr>
  <tr>
  <td bgcolor="#333333"></td>
  </tr>
</table></td>
<td width="150"><table>
  <tr bgcolor="#CCCCCC">
    <td><marquee direction="up" >
      <div align="center">
        <p class="Style1">----------------------------- <span class="Style4">Bienvenue</span></p>
        <p class="Style1">
          <?php if(isset($line))echo"$line[firstname] $line[lastname]"; ?>
          &nbsp; </p>
        <p class="Style1">-----------------------------</p>
        <p class="Style1">chez le guide du gestion des conf&eacute;rences.</p>
        <p class="Style1">----------------------------- </p>
      </div>
    </marquee></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td height="530" align="center" valign="top"><?php
	  if(isset($user)){
		  echo"
		       <p><h3>Action sur votre profil</h3></p>
			    <span class='Style1'>
			     <form action='/tp_finale_bdd/login.php?log=1' method='post'>
				  <input type='hidden' name='login' value='$line[username]'>
				  <input type='hidden' name='password' value='$line[password]'>
				  <input type='submit' class='button1' value='Accueil'>
				 </form>
				 <a href='/tp_finale_bdd/utilisateur/modifier_mon_profil.php?user=$line[username]'><input type='button' class='button1' value='Modifier'></a>
			     
			    </span>
		  ";
	  }
	 ?></td>
  </tr>
</table></td>
</tr>
</table>
</p>
<p>&nbsp;</p>
</body>
</html>