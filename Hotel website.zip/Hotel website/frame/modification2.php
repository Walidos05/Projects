<html>
  <head>
    <title>modification de donn�es en PHP :: partie2</title>
  </head>
<body>
<?php
  //connection au serveur:
  $cnx = mysql_connect( "localhost", "root", "" ) ;
 
  //s�lection de la base de donn�es:
  $db = mysql_select_db( "gestionconference" ) ;
 
  //r�cup�ration de la variable d'URL,
  //qui va nous permettre de savoir quel enregistrement modifier
  $usern  = $_GET["username"] ;
 
  //requ�te SQL:
  $sql = "SELECT *
            FROM users
    WHERE username =".$usern;
 
  //ex�cution de la requ�te:
  $requete = mysql_query( $sql, $cnx ) ;
 
  //affichage des donn�es:
  if( $result = mysql_fetch_object( $requete ) )
  {
  ?>
  <form name="insertion" action="modification3.php" method="POST">
  <input type="hidden" name="username" value="<?php echo($username) ;?>">
  <table border="0" align="center" cellspacing="2" cellpadding="2">
    <tr align="center">
      <td>username</td>
      <td><input type="text" name="username" value="<?php echo($result->username) ;?>"></td>
    </tr>
    <tr align="center">
      <td>firstname</td>
      <td><input type="text" name="firstname" value="<?php echo($result->firstname) ;?>"></td>
    </tr>
    <tr align="center">
      <td>lastname</td>
      <td><input type="text" name="lastname" value="<?php echo($result->lastname) ;?>"></td>
    </tr>
    <tr align="center">
      <td>adresse</td>
      <td><input type="text" name="adresse" value="<?php echo($result->adresse) ;?>"></td>
    </tr>
    <tr align="center">
      <td>telephone</td>
      <td><input type="text" name="telephone" value="<?php echo($result->telephone) ;?>"></td>
    </tr>
    <tr align="center">
      <td colspan="2"><input type="submit" value="modifier"></td>
    </tr>
  </table>
</form>
 <?php
  }//fin if 
  ?>
  </body>
</html>