<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd) or die ("connexion impossible..."); 

//cr�er une base de donn�es
$query = "create database gestionconference";
$result = mysql_query($query) or die ("<p><b>cr�ation de la base echou�e</b><p/>");

//s�lectionner la base avec laquelle on va travailler
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");

//cr�ation des tables et insertion des tuples
$query="CREATE TABLE users(username VARCHAR(15) UNIQUE NOT NULL,password VARCHAR(10) NOT NULL,firstname VARCHAR(20) NOT NULL,lastname VARCHAR(20) NOT NULL,organisation VARCHAR(20) NOT NULL,address VARCHAR(40) NOT NULL,city VARCHAR(15) NOT NULL,telephone INT NOT NULL,country VARCHAR(20) NOT NULL,category VARCHAR(20) UNIQUE NOT NULL,job VARCHAR(20) NOT NULL,PRIMARY KEY (username))";
$result = mysql_query($query) or die("<p><b>requette 1 echou�e</b><p/>");

//les nouvelle insertion
$query="insert into users values('pinky','kjhgffq','loiuhjnhggjvc','iujhygtre','fiugqhg','jhqifbx vqkshgnqkj','kjhqsq','1345673156','kjhgf','usa','ijuhygtq')";
$result = mysql_query($query) or die("<p><b>requette 2 echou�e</b><p/>");

$query="CREATE TABLE papers (paper_id VARCHAR(20) NOT NULL,title VARCHAR(20) NOT NULL,date DATE NOT NULL,keyword VARCHAR(20) NOT NULL,abstract VARCHAR(40) NOT NULL,language VARCHAR(20) NOT NULL ,PRIMARY KEY (paper_id))";
$result = mysql_query($query) or die("<p><b>requette 3 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into papers values ('KDGSFQF','carte �tudiant','21/05/2012','je ne sais pas','il n y a pas','fran�ais')";
$result = mysql_query($query) or die("<p><b>requette 4 echou�e</b><p/>");

$query="CREATE TABLE session(session_id VARCHAR(20) NOT NULL ,sessionname_en VARCHAR(20) NOT NULL,sessionname_fr VARCHAR(20) NOT NULL,PRIMARY KEY (session_id))";
$result = mysql_query($query) or die("<p><b>requette 8 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into session values ('poiuh','kdsghqkfq','loiuhgjvc')";
$result = mysql_query($query) or die("<p><b>requette 9 echou�e</b><p/>");

$query="CREATE TABLE paper_session(session_id VARCHAR(20),paper_id VARCHAR(20),foreign key(paper_id) references papers(paper_id),foreign key(session_id) references session(session_id))";
$result = mysql_query($query) or die("<p><b>requette 65 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into paper_session values ('poiuh','KDGSFQF')";
$result = mysql_query($query) or die("<p><b>requette 5 echou�e</b><p/>");

$query="CREATE TABLE responsable (username VARCHAR(15) UNIQUE NOT NULL,session_id VARCHAR(20) NOT NULL,foreign key(username)references users(username),foreign key(session_id)references session(session_id))";
$result = mysql_query($query) or die("<p><b>requette 6 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into responsable values ('pinky','poiuh')";
$result = mysql_query($query) or die("<p><b>requette 7 echou�e</b><p/>");

$query="CREATE TABLE author_paper (username VARCHAR(15)NOT NULL,paper_id VARCHAR(20) NOT NULL,foreign key(username) references users (username),foreign key(paper_id) references papers(paper_id))";
$result = mysql_query($query) or die("<p><b>requette 10 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into author_paper values ('pinky','KDGSFQF')";
$result = mysql_query($query) or die("<p><b>requette 11 echou�e</b><p/>");

$query="CREATE TABLE commitee_session(username VARCHAR(15) UNIQUE NOT NULL,session_id VARCHAR(20) NOT NULL, PRIMARY KEY (username,session_id),foreign key(username) references users(username),foreign key(session_id) references session(session_id))";
$result = mysql_query($query) or die("<p><b>requette 12 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into commitee_session values ('pinky','poiuh')";
$result = mysql_query($query) or die("<p><b>requette 13 echou�e</b><p/>");

$query="CREATE TABLE tutorial(tutorial_id int NOT NULL,author VARCHAR(20) NOT NULL,datetutor DATE NOT NULL,timetutor TIME NOT NULL,PRIMARY KEY (tutorial_id))";
$result = mysql_query($query) or die("<p><b>requette 18 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into tutorial values ('0987','uzihqkfq','30/04/2013','01:03')";
$result = mysql_query($query) or die("<p><b>requette 19 echou�e</b><p/>");


$query="CREATE TABLE tutor_regis(tutorial_id int NOT NULL,username VARCHAR(15) UNIQUE NOT NULL,foreign key(username) references users(username),foreign key(tutorial_id) references tutorial(tutorial_id))";
$result = mysql_query($query) or die("<p><b>requette 14 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into tutor_regis values ('0987','pinky')";
$result = mysql_query($query) or die("<p><b>requette 15 echou�e</b><p/>");

$query="CREATE TABLE hotels(hotel_id INT NOT NULL,name VARCHAR(20) NOT NULL,price INT NOT NULL,PRIMARY KEY (hotel_id))";
$result = mysql_query($query) or die("<p><b>requette 16 echou�e</b><p/>");




//les nouvelle insertion
$query="insert into hotels values ('34','uytrdf','25242')";
$result = mysql_query($query) or die("<p><b>requette 17 echou�e</b><p/>");


//les nouvelle insertion 

//$query="insert into tutorial values ('0987','uzihqkjfq','30/04/2013','01:03')";
//$result = mysql_query($query) or die("<p><b>requette 19 echou�e</b><p/>");


$query="CREATE TABLE registrations(username VARCHAR(15) UNIQUE NOT NULL,category VARCHAR(20) NOT NULL,hotel_id int NOT NULL ,days int,totalcost int,paid VARCHAR(10),foreign key(username) references users(username),foreign key(category) references users(category),foreign key(hotel_id) references hotels(hotel_id))";
$result = mysql_query($query) or die("<p><b>requette 20 echou�e</b><p/>");
//les nouvelle insertion


//$query="insert into registrations values ('pinky','urtghqkfq','0987','3','567825','khgjg')";
//$result = mysql_query($query) or die("<p><b>requette 21 echou�e</b><p/>");

$query="CREATE TABLE committeelocal(username VARCHAR(15) UNIQUE NOT NULL,PRIMARY KEY (username),foreign key(username) references users(username))";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into committeelocal values ('pinky')";
$result = mysql_query($query) or die("<p><b>requette 23 echou�e</b><p/>");

$query="CREATE TABLE committee_paper(username VARCHAR(15) UNIQUE NOT NULL,paper_id VARCHAR(20) NOT NULL,summary VARCHAR(50),comment VARCHAR(50),favourable VARCHAR(50),against VARCHAR(50),clarity int NOT NULL,relevance int NOT NULL,originality int NOT NULL,acceptance int NOT NULL,PRIMARY KEY (username, paper_id),foreign key(username) references users(username),foreign key(paper_id) references papers(paper_id))";
$result = mysql_query($query) or die("<p><b>requette 24 echou�e</b><p/>");
//les nouvelle insertion
$query="insert into committee_paper values ('pinky','KDGSFQF','oihgfd','jhgfd','poiuygtfd','lkjhgfdsdfghjk','876','6754','41571','212')";
$result = mysql_query($query) or die("<p><b>requette 25 echou�e</b><p/>");

echo"La base est cr�e avec succ�s";

?>
