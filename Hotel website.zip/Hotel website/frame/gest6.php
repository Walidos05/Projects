<?php
$code=$_GET['paper_id'];
      mysql_connect ("localhost","root","");
      mysql_select_db("gestionconference");
      $result = mysql_query("DELETE FROM papers WHERE paper_id='$paper_id'");
      echo"<br> <h3><strong> suupprim&eacute;e avec succ�s.</h3></strong>";
 
      ?>