<html>
<body>
<style type="text/css">
html, body {margin:0; padding:0; width:100%; height:100%; overflow:hidden; text-align:left;}
body {font-family: 'Tinos', serif;}
#background{position:absolute; z-index:1; width:100%; height:100%;}
#fixed {position:absolute; top:25px; left:10px; width:160px; z-index:10; color:#333; padding:10px;}
#scroller {position:absolute; width:100%; height:100%; top:5; left:5; overflow:auto; z-index:3;} 
#content {padding:20px 20px 20px 200px;}
p {font-size:16px; text-align:justify; line-height:25px; text-shadow: 0 1px 2px rgba(0,0,0,0.5), 0px -1px 2px rgba(255,255,255,0.8);}
h1 {font-family: 'Salsa', cursive; font-size:50px; color:#248; padding-left:20%; text-shadow: 0 5px 10px rgba(0,0,0,0.5), 0px -5px 10px rgba(255,255,255,0.8);}
h2 {font-family: 'Salsa', cursive; font-size:40px; color:#248; padding-left:1.5%; text-shadow: 0 4px 8px rgba(0,0,0,0.5), 0px -4px 8px rgba(255,255,255,0.8);}
h3 {font-family: 'Salsa', cursive; font-size:30px; color:#248; padding-left:1.5%; text-shadow: 0 3px 6px rgba(0,0,0,0.5), 0px -3px 6px rgba(255,255,255,0.8);}
h4 {font-family: 'Salsa', cursive; font-size:25px; color:#369; padding-left:1.5%; text-shadow: 0 2px 4px rgba(0,0,0,0.5), 0px -2px 4px rgba(255,255,255,0.8);}
.Col {width:25%; float:left; padding:2%; min-width:300px;}
</style>
</head>
<body>
<div>
	<img id="background" src="rose.jpg" alt="" title="" /> 
</div>
<div id="scroller">
<div id="content">
<div id="fixed">
<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd) or die ("connexion impossible..."); 

//cr�er une base de donn�es
$query = "create database gestionclient";
$result = mysql_query($query) or die ("<p><ol><ol><ol><ol><ol><font face='Times New Roman'size='14'color='white'><b>cr�ation.de.la.base.echou�e</b><p/>");

//s�lectionner la base avec laquelle on va travailler
mysql_select_db("gestionclient") or die("ne peut pas selectionner la base indiqu�e");

//cr�ation des tables et insertion des tuples
$query="CREATE TABLE client(code tinyint NOT NULL, nom varchar(20),prenom varchar(20),adress varchar(20),numpiece int, PRIMARY KEY(code))";
$result = mysql_query($query) or die("<p><b>requette 1 echou�e</b><p/>");

$query="CREATE TABLE facture(idfact tinyint NOT NULL, datefact date, PRIMARY KEY(idfact),code tinyint NOT NULL,foreign key(code) references client(code))";
$result = mysql_query($query) or die("<p><b>requette 2 echou�e</b><p/>");

$query="CREATE TABLE resarvation(numres tinyint NOT NULL, dateres date,datear date,datedep date,montant int, PRIMARY KEY(numres))";
$result = mysql_query($query) or die("<p><b>requette 3 echou�e</b><p/>");

$query="CREATE TABLE hotel(idhot tinyint NOT NULL,nomhot varchar(20),adresshot varchar(20),tele int,class varchar(20), PRIMARY KEY(idhot))";
$result = mysql_query($query) or die("<p><b>requette 4 echou�e</b><p/>");


$query="insert into hotel values (55,'chinestar','didouchemourad',079128563,'5etoile')";
$result = mysql_query($query) or die("<p><b>requette 23 echou�e</b><p/>");


$query="CREATE TABLE chambre(numch tinyint NOT NULL, numtele int,etat varchar(20), PRIMARY KEY(numch),idhot tinyint NOT NULL ,foreign key(idhot) references hotel(idhot))";
$result = mysql_query($query) or die("<p><b>requette 5 echou�e</b><p/>");

$query="insert into chambre values (01,020554,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (02,0215445,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (03,0224574,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (04,023777,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (05,024787,'occuper',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");
$query="insert into chambre values (06,0205542,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (07,02154453,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (08,02245743,'occuper',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (09,0237773,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (10,0247873,'occuper',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");
$query="insert into chambre values (11,0205543,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (12,02154453,'libre',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (13,02245743,'occuper',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (14,0237773,'occuper',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");

$query="insert into chambre values (15,0247873,'occuper',55)";
$result = mysql_query($query) or die("<p><b>requette 22 echou�e</b><p/>");


$query="CREATE TABLE reserver(numch tinyint NOT NULL, code tinyint NOT NULL ,numres tinyint NOT NULL, PRIMARY KEY(numch,code,numres))";
$result = mysql_query($query) or die("<p><b>requette 6 echou�e</b><p/>");


//cr�ation des r�les
echo'<ol><ol><ol><ol><ol><font face="Times New Roman"size="14"color="white">La.base.est.cr�e.avec.succ�s</font>';

?>
</html>
</body>
