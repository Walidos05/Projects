<?php
  //connection au serveur
  $cnx = mysql_connect( "localhost", "root", "" ) ;
 
  //s�lection de la base de donn�es:
  $db  = mysql_select_db( "gestionconference" ) ;
 
  //r�cup�ration des valeurs des champs:
  //username:
  $username     = $_POST["username"] ;
  //nom:
  $firstname = $_POST["firstname"] ;
  //prenom:
  $lastname = $_POST["lastname"] ;
  //adresse:
  $adresse        = $_POST["adresse"] ;
  //num�ro de t�l�phone:
  $telephone   = $_POST["telephone"] ;
 
  //r�cup�ration de l'identifiant de la personne:
  $username         = $_POST["username"] ;
 
  //cr�ation de la requ�te SQL:
  $sql = "UPDATE users
            SET username         = '$username', 
	          firstname     = '$firstname',
		  lastname    = '$lastname',
		  adresse           = '$adresse',
		  telephone = '$telephone'
           WHERE username = '$username' " ;
 
  //ex�cution de la requ�te SQL:
  $requete = mysql_query($sql, $cnx) or die( mysql_error() ) ;
 
 
  //affichage des r�sultats, pour savoir si la modification a march�e:
  if($requete)
  {
    echo("La modification � �t� correctement effectu�e") ;
  }
  else
  {
    echo("La modification � �chou�e") ;
  }
?>