import React from 'react'

function NoAccess() {
  return (
    <div className="container p-4">
      <h2>No Access</h2>
    </div>
  )
}

export default NoAccess