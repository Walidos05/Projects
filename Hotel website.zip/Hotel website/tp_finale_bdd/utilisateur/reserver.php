<?php
$user=$_GET["user"];
mysql_connect ("localhost","root","");
mysql_select_db("gestionconf");
$result= mysql_query("SELECT * FROM users WHERE username='$user'");
$nb = mysql_numrows($result);
$line = mysql_fetch_assoc($result);
$gestion="<p><strong>Gestion des sessions</strong></p>
		<a class='style1' href='/tp_finale_bdd/session/ajout_session.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'>
		</a><br>
		<a class='style1' href='/tp_finale_bdd/session/liste_session.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>
		    <p><strong>Gestion des tutoriels</strong></p>
		<a class='style1' href='/tp_finale_bdd/tutoriel/ajout_tutoriel.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/add.png'>
		 <input type='button' class='button1' value='Ajouter'>
		</a><br>
	    <a class='style1' href='/tp_finale_bdd/tutoriel/liste_tutoriel.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
		</a><br>
			  <p><strong>Gérer les papiers</strong></p>
		 <img src='/tp_finale_bdd/img/add.png'>
		  <input type='button' class='button1' value='Ajouter'><img src='/tp_finale_bdd/img/vous_etes_ici.jpg'>
		<br>
		<a class='style1' href='/tp_finale_bdd/papier/liste_papier.php?user=$line[username]&voir=2'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>
			  <p><strong>Gestion des utilisateurs</strong></p>
		<a class='style1' href='/tp_finale_bdd/utilisateur/liste.php?user=$line[username]'>
		 <img src='/tp_finale_bdd/img/rech.png'>
		 <input type='button' class='button1' value='voir tous'>
	    </a><br>";

?>

<html>
<head>
<title>Profil <?php if($line){echo"de $line[firstname] $line[lastname]";}?></title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

.Style1 {color: #FF0000}
.Style4 {font-size: 24px}
.button1 { border:hidden; background-image:url(/tp_finale_bdd/img/button.png); width:85; height:20}

</style>
</head>
<body background="/tp_finale_bdd/img/shadow.jpg" style="background-size:cover">
<p>
<table cellspacing="0" cellpadding="8" width="999" align="center" border="0">
<tr valign="top">
<td width="142"><table width="142" height="252" border="0">
  <tr>
    <td width="136" height="30" bgcolor="#CCCCCC">vous pouvez &eacute;galement:</td>
  </tr>
  <tr valign="top" bgcolor="#CCCCCC">
    <td height="700" align="center"><?php
    echo"$gestion";
	?></td>
  </tr>
</table></td>
<td width="659" valign="top">
  <table cellspacing="0" cellpadding="8" width="651" align="left" border="0">
    <tr>
      <td width="635" height="200" BACKGROUND="/tp_finale_bdd/img/copie-_2_-de-fotolia_10430113_s.jpg">
        <h1 align="center"><br>
        <img src="/tp_finale_bdd/img/home.png" height="42" width="42">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#ffffff">R&eacute;servation</font></h1></td></tr>
    <tr>
      <td background="/tp_finale_bdd/img/shadow1.bmp">
        <p>&nbsp;</p>
        </td>
      </tr>
    <tr>
      <td height="480" valign="top" style="background-image:url(/tp_finale_bdd/img/bg.png)">
        <p align="center"><font color="#000000" size="6">R&eacute;servation</font></p>
        <p align="left">
  <?php
if(isset($_GET["ajouté"])){
$result = mysql_query("INSERT INTO registrations VALUES ('$_POST[utilisateur]','$_POST[utilisateur_category]','$_POST[jour1]','$_POST[jour2]','$_POST[jour3]','$_POST[jour4]','$_POST[jour5]','$_POST[jour6]','$_POST[tour]','$_POST[total],'$_POST[payed]'')");

if($result){echo"<br><h3><strong>place réserv&eacute;e avec succ&eacute;.</h3></strong>";}
else{echo"Désolé, une faute est survenue pendant la r&eacute;servation.";}
}else{
	$utilisateur=$_GET['code'];
$select=mysql_query("select * from hotels");
$select_user=mysql_query("select * from users WHERE username='$utilisateur'");
$selected_user=mysql_fetch_assoc($select_user);
$utilisateur_category=$selected_user['category'];
echo"<form action='reserver.php?ajouté=1&user=$user' method='post'>
 <p align='center'><strong><div align='center' style=\"background-color:#666; color:#FFF; text-height:80;\">veuillez remplir le formulaire ci-dessous les champs avec &eacute;toile (*) sont obligatoire.</div></strong></p>
 <center>
 <table>
 <tr><td>* Hotel</td><td><select name='hotel'>";
    while($line1=mysql_fetch_assoc($select)){
	      {echo"<option value='$line1[username]'>$line1[name]</option>";}
    }
	echo"</select><input type='hidden' name='utilisateur' value='$utilisateur'><input type='hidden' name='utilisateur_category' value='$utilisateur_category'></td></tr>
 <tr><td>* jour1 (n=° de jour du mois)</td><td><input name='jour1'></td></tr>
 <tr><td>* jour2 (n=° de jour du mois)</td><td><input name='jour2'></td></tr>
 <tr><td>* jour3 (n=° de jour du mois)</td><td><input name='jour3'></td></tr>
 <tr><td>* jour4 (n=° de jour du mois)</td><td><input name='jour4'></td></tr>
 <tr><td>* jour5 (n=° de jour du mois)</td><td><input name='jour5'></td></tr>
 <tr><td>* jour6 (n=° de jour du mois)</td><td><input name='jour6'></td></tr>
 <tr><td>* tour</td><td><select name='tour'>";
		  $select_tour=mysql_query('select * from tutorials');
    while($line1=mysql_fetch_assoc($select_tour)){
	      {echo"<option value='$line1[username]'>$line1[title]</option>";}
    }
	echo"</select></td></tr>
 <tr><td>* total &agrave; payer</td><td><input name='total'></td></tr>
 <tr><td>* &agrave; payer par le site</td><td><input name='payed'></td></tr>
 </table>
 <input name='nb' type='hidden' value='$nb'>
 <input class='button1' type='submit' value='Ajouter'>
 </center>
</form>";};

?>
  </p>
        <p></p></td></tr>
    <tr>
      <td bgcolor="#333333"></td>
      </tr>
</table></td>
<td width="150"><table>
  <tr bgcolor="#CCCCCC">
    <td><marquee direction="up" >
      <div align="center">
        <p class="Style1">----------------------------- <span class="Style4">Bienvenue</span></p>
        <p class="Style1">
          <?php if(isset($line))echo"$line[firstname] $line[lastname]"; ?>
          &nbsp; </p>
        <p class="Style1">-----------------------------</p>
        <p class="Style1">chez le guide du gestion des conf&eacute;rences.</p>
        <p class="Style1">----------------------------- </p>
      </div>
    </marquee></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td height="530" align="center" valign="top"><?php
	  if(isset($user)){
		  echo"
		       <p><h3>Action sur votre profil</h3></p>
			    <span class='Style1'>
			     <form action='/tp_finale_bdd/login.php?log=1' method='post'>
				  <input type='hidden' name='login' value='$line[username]'>
				  <input type='hidden' name='password' value='$line[password]'>
				  <input type='submit' class='button1' value='Accueil'>
				 </form>
				 <a href='/tp_finale_bdd/utilisateur/modifier_mon_profil.php?user=$line[username]'><input type='button' class='button1' value='Modifier'></a>
			     
			    </span>
		  ";
	  }
	 ?></td>
  </tr>
</table></td>
</tr>
</table>
</p>
<p>&nbsp;</p>
</body>
</html>