<html>
<head>
<title>HTML Frames Example - Menu 2</title>
<style type="text/css">
body {
	font-family:verdana,arial,sans-serif;
	font-size:10pt;
	margin:10px;
	background-color:#ff6600;
	}
</style>
</head>
<body background="bebe.jpg">
<h3><center>Bienvenue Bensaada Hakim Boussioud SARA</h3>

<style>#web-buttons-idhb635 a{display:block;color:transparent;} #web-buttons-idhb635 a:hover{background-position:left bottom;}a#web-buttons-idhb635a {display:none}</style>



<table id="web-buttons-idajbba" width=0 cellpadding=0 cellspacing=0 border=0>
<tr><td style="padding-bottom:27px" title ="Ajout">
<a href="ajout1.php" title="Ajout" style="background-image:url(a2-files/btajbba.png);width:142px;height:66px;display:block;"><br/></a></td></tr>
<tr><td style="padding-bottom:27px" title ="Affichage">
<a href="affichage1.php" title="Affichage" style="background-image:url(a2-files/btsjbba.png);width:142px;height:66px;display:block;"><br/></a></td></tr>
<tr><td style="padding-bottom:27px" title ="Supression">
<a href="#" title="Supression" style="background-image:url(a2-files/bt3jbba.png);width:142px;height:66px;display:block;"><br/></a></td></tr>
<tr><td style="padding-bottom:27px" title ="Recherche">
<a href="#" title="Recherche" style="background-image:url(a2-files/btrjbba.png);width:142px;height:66px;display:block;"><br/></a></td></tr>
<tr><td style="padding-bottom:27px" title ="D�conexion">
<a href="#" title="D�conexion" style="background-image:url(a2-files/bt6jbba.png);width:142px;height:66px;display:block;"><br/></a></td></tr>


</center>


</tr></table>

</body>
</html>
