<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<title>Un menu avec multiples survols sans preload d'images</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
<!--
/* CSS issu des tutoriels css.alsacreations.com */
body {
background: #000;
}
ul, li {	/* utilisation de liste pour le menu */
list-style-type: none;	/* suppression des puces de liste */
margin:0;
padding:0;
}
ul {
position: absolute;	/* positionnement pour IE5 et IE5.5 */
top: 0;
left: 100px;
background: transparent url(Photos-0044.jpg) top left no-repeat;	/* arri�re-plan g�n�ral du menu */
width: 1300px;
text-align: center;
}
li {float: left;}

li a {	/* dimensions et d�finitions des boutons */
display: block;	/* mise en block de <a> pour lui donner des dimensions */
height: 420px;
width: 100px;
color: #fff;
font-size: 14px;
line-height: 50px;	/* hauteur de ligne pour �viter les paddings */
font-weight: bold;
font-family: arial, serif;
text-decoration: none;
}
li a:hover {
background: transparent url(bebe.jpg) top left no-repeat;
}
a#lien1:hover {
background-position: -360px 0%;	/* d�calage de l'arri�re-plan pour chaque bouton */
}
a#lien2:hover {
background-position: -420px 0%;
}
a#lien3:hover {
background-position: -480px 0%;
}
a#lien4:hover {
background-position: -540px 0%;
}
a#lien5:hover {
background-position: -600px 0%;
}
a#lien6:hover {
background-position: -660px 0%;
}

/* mentions et copyright */
div#mentions {
  font-family: verdana, arial, sans-serif;
  position: absolute;
  bottom : 100px;
  left : 10px;
  width: 400px;
  margin: 1em;
  padding: 0.5em;
  background: #FFF7D2;
  -moz-border-radius:10px;
  border-radius:10px;
  line-height: 1.1;
  font-size: 0.9em;
}
div#mentions a {
  text-decoration: none;
  color: #222;
}
div#mentions a:hover {
  text-decoration: underline;
  color: black;
}

-->
</style>
</head>
<body>
<ul>
	<li><a id="user" href="listepaper.php">Papers</a></li>
	<li><a id="autho" href="listeauthorpaper.php">Author papers</a></li>
	<li><a id="lien3" href="listehotel.php">Hotel</a></li>
	<li><a id="lien4" href="listecommitteepaper.php">Commitee papers</a></li>
	<li><a id="lien1" href="listecommitteelocal.php">Commitee local</a></li>
	<li><a id="lien2" href="listecommiteesession.php">Commite session</a></li>
	<li><a id="lien3" href="listepapersession.php">Paper session</a></li>
	<li><a id="lien4" href="listepersonne.php">Personne</a></li>
	<li><a id="lien3" href="listeregistrations.php"> Registration</a></li>
	<li><a id="lien4" href="listeresponsable.php">Responsable</a></li>
	<li><a id="lien2" href="listesession.php"> Session</a></li>
	<li><a id="lien3" href="listetutorial.php">Tutorial</a></li>
	<li><a id="lien4" href="listepersonne.php"> User</a></li>
</ul>

</body>
</html>
