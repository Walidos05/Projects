<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "ajouterhotels.php?inserthotels=1">
<table border="1" width="403">
    <p>formulaire d'ajout d'un hotels</p>

    <tr>
      <td width="141" bgcolor='4407FA'>hotel id</td>
      <td width="312"><input type="text" name="hotel_id"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>Name</td>
      <td width="312"><input type="text" name="name"></td>
    </tr>
    <tr>
    <tr>
      <td width="141" bgcolor='4407FA'>Price</td>
      <td width="312"><input type="text" name="price"></td>
    </tr>
    
      
<?php

$inserthotels =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['inserthotels'])){
      $h=$_POST['hotel_id'];
	  $n=$_POST['name'];
      $p=$_POST['price'];
      	  
  //insertion de tuples
      $query="INSERT INTO hotels VALUES ('$h','$n','$p')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>Utilisateur ajout� avec succ�s";
      }
else{};
?>

