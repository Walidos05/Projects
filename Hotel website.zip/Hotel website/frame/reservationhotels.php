<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "reservationhotels.php?inserthotels=1">
<table border="1" width="403">
    <p>RESERVATION D'HOTEL</p>
	
<li>HOTEL ID :<input type="text" name="hotelid"  size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>NAME:<input type="text" name="name" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>PRICE:<input type="text" name="price" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>

      
<?php

$inserthotels =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['inserthotels'])){
      $h=$_POST['hotelid'];
	  $n=$_POST['name'];
      $p=$_POST['price'];
      	  
  //insertion de tuples
      $query="INSERT INTO hotels VALUES ('$h','$n','$p')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>R�servaion avec succ�s";
      }
else{};
?>
<html>
<h1><a href="content.php"><img src="retour1.jpg" width="100" height="100"><span class="Style5"><font color="BLACK"></span></a></h1>

<html>
