export const SET_USER = "SET_USER";
export const ERRORS = "ERRORS";
export const SET_PROFILE = "SET_PROFILE";
export const SET_PROFILES = "SET_PROFILES";
export const DELETE_PROFILE = "DELETE_PROFILE";