<?php
$code=$_GET['session_id'];
      mysql_connect ("localhost","root","");
      mysql_select_db("gestionconference");
      $result = mysql_query("DELETE FROM session WHERE session_id='$session_id'");
      echo"<br> <h3><strong> suupprim&eacute;e avec succ�s.</h3></strong>";
 
      ?>