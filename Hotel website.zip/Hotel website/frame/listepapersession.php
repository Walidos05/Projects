<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<?php
$query = "SELECT * FROM paper_session";
$result = mysql_query($query) or die("requette echou�e");
?>
<b>LISTE DES PAPER_SESSIONS:</b><br><br>
<table border=\"1\">
<tr bgcolor='4407FA'>
    	<td><b>session id</b></td> 
		<td><b>paper id</b></td>
	    <td><b>Modifier</b></td>
	    <td><b>Supprimer</b></td>
</tr>

<?php
//Afficher tous les utilisateurs
while ($line = mysql_fetch_assoc($result)) {//renvoie un tableau dont les cl�s sont les noms des champs s�lectionn�s.
      echo "<tr>";
      echo "<td>$line[session_id]</td>";
      echo "<td>$line[paper_id]</td>";
	    
	    
		
	    echo "<td><a href=\"gestuser.php?chusers=$line[session_id]\">modifier</a></td>";
			echo "<td align=left><a href=\"gest7.php?delUser=$line[session_id]\" onclick=\"javascript:return confirm('ETE VOUS SUR DE VOULOIRE SUPRIMER ?');\">supprimer</a></td>";
      echo "</tr>";
}

echo "</table>";
?>
<html>
<h1><a href="content.php"><img src="retour1.jpg" width="100" height="100"><span class="Style5"><font color="BLACK"></span></a></h1><br>


<html>

