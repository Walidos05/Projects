<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

<link href="css/styleinfo.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">

var time=0
tbtxt=new Array("Suite aux negocitions rat�s les salaries de boulex on mis leurs menace a execution.","Il on finalement decide de se marie l'ete prochain","A l'assemble la lois sur la retraite a 100 ans vient enfin d'etre vote","afin d'augmenter ses revenus la bourse organise un qu�te","La rencontre entre l'om et le psg 10 a 1 en faveur ...");
tbtitre=new Array("boulex","ils se maries","retraite","qu�te","OM PSG");
tbimage=new Array("explosion.jpg","sarcoz.jpg","asse.jpg","fric.jpg","psgom.jpg");
tblien=new Array("coucou.html","me.html","voila.html","c'est.html","ca.html");

function ctcop(txt){
time=txt;
document.getElementById('centre').firstChild.nodeValue=tbtxt[txt];
document.getElementById('titre').firstChild.nodeValue=tbtitre[txt];
document.getElementById('gema').src="image/"+tbimage[txt];
document.getElementById('lien').setAttribute("href",tblien[txt]);

for (i=0; i<document.getElementById('mini').getElementsByTagName('li').length; i++){
if(document.getElementById('mini').getElementsByTagName('li')[(i)].style.backgroundColor='black'){
document.getElementById('mini').getElementsByTagName('li')[i].style.backgroundColor='blue';
}
}
document.getElementById('mini').getElementsByTagName('li')[txt].style.backgroundColor='black';
}

function difile(){
if(time==tbtxt.length){
time=0;
}
ctcop(time);
time++;
setTimeout("difile(time)",1000);
}
</script>

</head>
<body onload='difile()'>

<div id='fond'>

<div id='ima'>
<a id='lien' href='azerty.html'><img id='gema'></a>
</div>

<div id='mini'>
<ul>
<li onclick=ctcop(0)>societe</li>
<li onclick=ctcop(1)>people</li>
<li onclick=ctcop(2)>politique</li>
<li onclick=ctcop(3)>bourse</li>
<li onclick=ctcop(4)>sport</li>
</ul>
</div>

<div id='infotexte'>
<span id='titre'>titre</span>
<span id='centre'>bla bla bla bla bla bla</span>
</div>

</div>

</body>
</html>
