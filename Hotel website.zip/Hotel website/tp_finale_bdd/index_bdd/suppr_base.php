<html>
<head>
<title>Page d'Accueil</title>
<style>
a.navwhite:link { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:visited { text-decoration: none; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navwhite:hover { text-decoration: underline; color: #ffffff; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:link { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:visited { text-decoration: none; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }
a.navblack:hover { text-decoration: underline; color: #000000; font-family: Verdana, Arial, sans-serif; font-size: 10px; font-weight: bold; }

h1 { font-family: Arial, sans-serif; font-size: 30px; color: #a80000;}
h2 { font-family: Arial, sans-serif; font-size: 18px; color: #a80000;}

body,p,b,i,em,dt,dd,dl,sl,caption,th,td,tr,u,blink,select,option,form,div,li { font-family: Arial, sans-serif; font-size: 12px; }

.Style1 {color: #FF0000}
.Style4 {font-size: 24px}
.button { border:hidden; background-color:#00F; color:#FFF; width:85; height:25 }
.button1 { border:hidden; background-image:url(/tp_finale_bdd/img/button.png); width:85; height:20}
.input { border-bottom:#FFF; background-color:#E4E4E4; height:25}
</style>

</head>
<body style="background-image:url(/tp_finale_bdd/img/shadow.jpg); background-size:cover" >
<?php
$connection= mysql_connect ("localhost","root","");
$result1 = mysql_query("drop database gestionconf ");

?>
<p>
<table cellspacing="0" cellpadding="8" width="970" align="center" border="0">
<tr id="tr1">
<td valign="top" width="150" id="td1"><table width="150" height="350" border="0">
  <tr>
    <td height="123" bgcolor="#CCCCCC"><marquee direction="up">
      <div align="center">
        <p class="Style1">&nbsp;</p>
      </div>
    </marquee></td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC" height="600"></td>
  </tr>
</table></td>
<td width="670">
<table cellspacing="0" cellpadding="8" width="670" align="center" border="0">
  <tr>
    <td width="641" height="200" BACKGROUND="/tp_finale_bdd/img/copie-_2_-de-fotolia_10430113_s.jpg">
      <h1 align="center"><br>
        <img src="img/home.png" height="30" width="30">       <?php if($connection){echo"Suppression termin&eacute;e";};?></h1></td></tr>
  <tr>
        <td style="background-image:url(/tp_finale_bdd/img/shadow1.bmp)" align="right">
        <p></td>
  </tr>
  <tr style="background-image:url(/tp_finale_bdd/img/bg.png)">
    <td height="510" valign="top">

<?php

echo"<h3><strong>La base est supprim&eacute;e avec succ�s.</strong></h3>";


?>&nbsp;</td></tr>
  <tr bgcolor="#333333">
  <td></td>
  </tr>
</table></td>
<td height="650" bgcolor="#CCCCCC"></td>
</tr>
</table>
</p>
<p>&nbsp;</p>
</body>
</html>