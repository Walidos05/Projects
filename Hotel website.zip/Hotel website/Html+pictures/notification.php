<html>
<body>
<style type="text/css">
html, body {margin:0; padding:0; width:100%; height:100%; overflow:hidden; text-align:left;}
body {font-family: 'Tinos', serif;}
#background{position:absolute; z-index:1; width:100%; height:100%;}
#fixed {position:absolute; top:25px; left:10px; width:160px; z-index:10; color:#333; padding:10px;}
#scroller {position:absolute; width:100%; height:100%; top:5; left:5; overflow:auto; z-index:3;} 
#content {padding:20px 20px 20px 200px;}
p {font-size:16px; text-align:justify; line-height:25px; text-shadow: 0 1px 2px rgba(0,0,0,0.5), 0px -1px 2px rgba(255,255,255,0.8);}
h1 {font-family: 'Salsa', cursive; font-size:50px; color:#248; padding-left:20%; text-shadow: 0 5px 10px rgba(0,0,0,0.5), 0px -5px 10px rgba(255,255,255,0.8);}
h2 {font-family: 'Salsa', cursive; font-size:40px; color:#248; padding-left:1.5%; text-shadow: 0 4px 8px rgba(0,0,0,0.5), 0px -4px 8px rgba(255,255,255,0.8);}
h3 {font-family: 'Salsa', cursive; font-size:30px; color:#248; padding-left:1.5%; text-shadow: 0 3px 6px rgba(0,0,0,0.5), 0px -3px 6px rgba(255,255,255,0.8);}
h4 {font-family: 'Salsa', cursive; font-size:25px; color:#369; padding-left:1.5%; text-shadow: 0 2px 4px rgba(0,0,0,0.5), 0px -2px 4px rgba(255,255,255,0.8);}
.Col {width:25%; float:left; padding:2%; min-width:300px;}
</style>
</head>
<body>
<div>
	<img id="background" src="re.jpg" alt="" title="" /> 
</div>
<div id="scroller">
<div id="content">
<div id="fixed">
<ol><ol><ol><ol><font size="12"><p>bienvenue&nbsp;dans&nbsp;notre&nbsp;hotel</font></p>
<p>L�h�tel&nbsp;SHINE&nbsp;STAR&nbsp;vous&nbsp;propose&nbsp;plusieurs&nbsp;suites,&nbsp;des&nbsp;chambres&nbsp;doubles&nbsp;Deluxe,<br> des&nbsp;chambres&nbsp;doubles&nbsp;Superior&nbsp;et&nbsp;des&nbsp;chambres&nbsp;familiales.<br>Toutes&nbsp;les&nbsp;pi�ces&nbsp;ont&nbsp;�t�&nbsp;am�nag�es&nbsp;avec&nbsp;les&nbsp;meubles&nbsp;et&nbsp;les&nbsp;�uvres&nbsp;d�art&nbsp;qu�il&nbsp;a&nbsp;cr��s.</p>

<p>notre&nbsp;nom&nbsp;de&nbsp;hotel&nbsp;est:&nbsp;SHINE&nbsp;STAR</p>
<p>notre&nbsp;adress&nbsp;est:&nbsp;rue&nbsp;didouche&nbsp;mourad</p>
<p>si&nbsp;vous&nbsp;voulez&nbsp;contacter&nbsp;notre&nbsp;telephone&nbsp;est:&nbsp;022222222222</p>
<p>notre&nbsp;siteweb&nbsp;est:&nbsp;www.STAR_HOTEL.com</p>
<p>la&nbsp;class&nbsp;de&nbsp;notre&nbsp;hotel&nbsp;est:5&nbsp;etoiles</p>
<ol><ol><font face="Times New Roman"size="12"><a href='menu.php'>Retour.au.menu</a>
</html>
</body>








