<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<?php
$query = "SELECT * FROM tutorial";
$result = mysql_query($query) or die("requette echou�e");
?>
<b>LISTE DES TUTORIAL :</b><br><br>
<table border=\"1\">
<tr bgcolor='4407FA'>
    	<td><b>tutorial id</b></td> 
		<td><b>author</b></td>
		<td><b>date tutorial</b></td>
		<td><b>time tutorial</b></td>
	    <td><b>Modifier</b></td>
	    <td><b>Supprimer</b></td>
</tr>

<?php
//Afficher tous les utilisateurs
while ($line = mysql_fetch_assoc($result)) {//renvoie un tableau dont les cl�s sont les noms des champs s�lectionn�s.
      echo "<tr>";
      echo "<td>$line[tutorial_id]</td>";
      echo "<td>$line[author]</td>";
	  echo "<td>$line[datetutor]</td>"; 
	  echo "<td>$line[timetutor]</td>";  
		
	    echo "<td><a href=\"gestuser.php?chusers=$line[tutorial_id]\">modifier</a></td>";
			echo "<td align=left><a href=\"gest11.php?delUser=$line[tutorial_id]\" onclick=\"javascript:return confirm('ETE VOUS SUR DE VOULOIRE SUPRIMER ?');\">supprimer</a></td>";
      echo "</tr>";
}

echo "</table>";
?>
<html>
<h1><a href="content.php"><img src="retour1.jpg" width="100" height="100"><span class="Style5"><font color="BLACK"></span></a></h1><br>


<html>

