<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "inscription1.php?insertuser=1">
<table border="1" width="403">
    <p>formulaire d'ajout d'un utilisateur </p>

   
<li>PSEUDO:<input type="text" name="pseudo"  size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>MOT DE PASSE:<input type="text" name="motdepasse" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>NOM:<input type="text" name="nom" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>PRENOM:<input type="text" name="prenom" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>ORGANISATION:<input type="text" name="organisation" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>ADRESSE:<input type="text" name="adresse" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>CITY:<input type="text" name="city" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>TELEPHONE:<input type="text" name="telephone" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>COUNTRY:<input type="text" name="country" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>CATEGORY:<input type="text" name="category" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>
<li>JOB:<input type="text" name="job" size="30" style="border:solid 1px black; border-radius:5px; text-align:center; box-shadow:0 0 6px"/><br>

      
<?php

$insertuser =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['insertuser'])){
      $u=$_POST['pseudo'];
	  $p=$_POST['motdepasse'];
      $f=$_POST['nom'];
      $l=$_POST['prenom'];
      $o=$_POST['organisation'];  
	  $a=$_POST['adresse'];
	  $c=$_POST['city'];
	  $t=$_POST['telephone'];
	  $co=$_POST['country'];
	  $ca=$_POST['category'];
	  $j=$_POST['job'];
	  
  //insertion de tuples
      $query="INSERT INTO users VALUES ('$u','$p','$f','$l','$o','$a','$c','$t','$co','$ca','$j')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>inscription r�ussite ";
      }
else{};
?>
<html>
<h1><a href="content.php"><img src="retour1.jpg" width="100" height="100"><span class="Style5"><font color="BLACK"></span></a></h1>

<html>
