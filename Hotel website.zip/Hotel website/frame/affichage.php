<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
	<head>
		<!--  Created by Artisteer v3.0.0.32906  Base template (without user's data) checked by http://validator.w3.org : "This page is valid XHTML 1.0 Transitional"  -->
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Home</title>
		<link rel="stylesheet" href="./style.css" type="text/css" media="screen" />
		<!--[if IE 6]><link rel="stylesheet" href="./style.ie6.css" type="text/css" media="screen" /><![endif]-->
		<!--[if IE 7]><link rel="stylesheet" href="./style.ie7.css" type="text/css" media="screen" /><![endif]-->
		<script type="text/javascript" src="./jquery.js"></script>
		<script type="text/javascript" src="./script.js"></script>
	</head>
	<body>
		<div id="art-page-background-glare">
			<div id="art-page-background-glare-image">
				<div id="art-main">
					<div class="art-sheet">
						<div class="art-sheet-tl"></div>
						<div class="art-sheet-tr"></div>
						<div class="art-sheet-bl"></div>
						<div class="art-sheet-br"></div>
						<div class="art-sheet-tc"></div>
						<div class="art-sheet-bc"></div>
						<div class="art-sheet-cl"></div>
						<div class="art-sheet-cr"></div>
						<div class="art-sheet-cc"></div>
						<div class="art-sheet-body">
							<div class="art-header">
								<div class="art-header-center">
									<div class="art-header-jpeg"></div>
								</div>
								<div class="art-logo">
									<h1 id="name-text" class="art-logo-name"><a href="./index.html">Menu d'affichage</a></h1>
									<h2 id="slogan-text" class="art-logo-text">***********************************************************************************************************************************************************</h2>
								</div>
							</div>
							<div class="art-nav">
								<div class="l"></div>
								<div class="r"></div>
								<ul class="art-menu">
									<li><a href="./index.php" class="active"><span class="l"> </span><span class="r"> </span><span class="t">Acceill</span></a></li>
									<li><a href="./affichage/6.php"><span class="l"> </span><span class="r"> </span><span class="t">papier</span></a></li>
									<li><a href="./affichage/5.php"><span class="l"> </span><span class="r"> </span><span class="t">Hotel</span></a></li>
									<li><a href="./affichage/4.php"><span class="l"> </span><span class="r"> </span><span class="t">comittee papier</span></a></li>
									<li><a href="./affichage/3.php"><span class="l"> </span><span class="r"> </span><span class="t">commitee local</span></a></li>
									<li><a href="./affichage/2.php" class="active"><span class="l"> </span><span class="r"> </span><span class="t">commitee session</span></a></li>
									<li><a href="./affichage/1.php"><span class="l"> </span><span class="r"> </span><span class="t">Auteur paper</span></a></li>
									<li><a href="./affichage/7.php"><span class="l"> </span><span class="r"> </span><span class="t"> papier session</span></a></li>
								    <li><a href="./affichage/9.php"><span class="l"> </span><span class="r"> </span><span class="t">Registration</span></a></li>
									<li><a href="./affichage/10.php"><span class="l"> </span><span class="r"> </span><span class="t">Responsable</span></a></li>
									<li><a href="./affichage/11.php"><span class="l"> </span><span class="r"> </span><span class="t">Session</span></a></li>
									<li><a href="./affichage/12.php"><span class="l"> </span><span class="r"> </span><span class="t">Tutorial</span></a></li>
								    <li><a href="./affichage/8.php"><span class="l"> </span><span class="r"> </span><span class="t">Utilisateur</span></a></li>
									<li><a href="./affichage/13.php"><span class="l"> </span><span class="r"> </span><span class="t">tutoregistration </span></a></li>
								</ul>
							</div>
							<div class="art-content-layout">
								<div class="art-content-layout-row">
									<div class="art-layout-cell art-sidebar1">
										
										<div class="art-block">
											<div class="art-block-body">
												<div class="art-blockcontent">
													<div class="art-blockcontent-body">
													<div class="cleared"></div>
													</div>
												</div>
												<div class="cleared"></div>
											</div>
										</div>
										<div class="art-block">
											<div class="art-block-body">
												<div class="art-blockcontent">
													<div class="art-blockcontent-body">
														<div>
															<form method="get" name="searchform" action="#" enctype="application/x-www-form-urlencoded"><input type="text" value="" name="s" style="width: 95%;"></input>  ?<span class="art-button-wrapper"><span class="art-button-l"> </span><span class="art-button-r"> </span><a class="art-button" href="javascript:void(0)">Search</a></span>?  </form>
														</div>
														<div class="cleared"></div>
													</div>
												</div>
												<div class="cleared"></div>
											</div>
										</div>
										<div class="art-block">
											<div class="art-block-body">
												<div class="art-blockcontent">
													<div class="art-blockcontent-body">
														<div>
														</div>
														<div class="cleared"></div>
													</div>
												</div>
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
									<div class="art-layout-cell art-content">
										<div class="art-post">
											<div class="art-post-body">
												<div class="art-post-inner art-article">
													<h2 class="art-postheader"></h2>
													<div class="art-postcontent">
														<h2><span style="color: rgb(188, 188, 188); font-family: Tahoma, Arial, Helvetica, sans-serif; "><span style="color: rgb(247, 247, 247); font-family: Arial, Helvetica, sans-serif; "><span style="font-size: 12px;">?</span></span></span><span style="color: rgb(247, 247, 247); font-family: Arial, Helvetica, sans-serif; font-size: 12px; "><span style="color: rgb(34, 41, 43); font-family: 'Lucida Grande', 'Lucida Sans Unicode', Arial, Helvetica, sans-serif; text-transform: none; "><span></span></h2>
														<p><span style="color: rgb(247, 247, 247); font-family: Arial, Helvetica, sans-serif; font-size: 12px; "><span style="color: rgb(34, 41, 43); font-family: 'Lucida Grande', 'Lucida Sans Unicode', Arial, Helvetica, sans-serif; text-transform: none; "><br /></span></span></p>
														
														
														
													</div>
													<div class="cleared"></div>
												</div>
												<div class="cleared"></div>
											</div>
										</div>
										<div class="cleared"></div>
									</div>
								</div>
							</div>
							<div class="cleared"></div>
							<div class="art-footer">
								<div class="art-footer-t"></div>
								<div class="art-footer-body">
									<div class="art-footer-text">
									    <p>S.BOUSSIOUD ET H.BENSAADA</p>
										<p>Copyright ? 2013. All Rights Reserved.</p>
									</div>
									<div class="cleared"></div>
								</div>
							</div>
							<div class="cleared"></div>
						</div>
					</div>
					<div class="cleared"></div>
					<p class="art-page-footer">Designed by S.BOUSSIOUD ET H.BENSAADA</p>
				</div>
			</div>
		</div>
	</body>
</html>