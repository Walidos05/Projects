<?php
$serveur = "localhost";   //le serveur
$login = "root";   // l'utilisateur
$pwd = "";   // mot de passe

//ouvrir une connection
mysql_connect ($serveur,$login,$pwd)or die('connexion impossible...'); 

//S�lectionner une base de donn�es
mysql_select_db("gestionconference") or die("ne peut pas selectionner la base indiqu�e");
?>

<form method="post" action= "ajouterresponsable.php?insertresponsable=1">
<table border="1" width="403">
    <p>formulaire d'ajout d'un responsable</p>

    <tr>
      <td width="141" bgcolor='4407FA'>Username</td>
      <td width="312"><input type="text" name="username"></td>
    </tr>
	<tr>
      <td width="141" bgcolor='4407FA'>session_id</td>
      <td width="312"><input type="text" name="session_id"></td>
    </tr>
    
      
<?php

$insertresponsable =1;
?>
</td>
</tr>

<tr>
    <td colspan="2">
      <input type="submit" name="formbutton1" />
      <input type="reset" name="formbutton2" />
    </td>
  </tr>
</table>
</form>

<?php
//ajouter une ligne
if (isset($_GET['insertresponsable'])){
      $u=$_POST['username'];
	  $s=$_POST['session_id'];
      	  
  //insertion de tuples
      $query="INSERT INTO responsable VALUES ('$u','$s')";
      $result = mysql_query($query) or die("<b>requette echou�e".mysql_error()."</b>");
      echo "<b>Utilisateur ajout� avec succ�s";
      }
else{};
?>

