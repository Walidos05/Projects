<html>
<head>
<title>HTML Frames Example - Menu 2</title>
<style type="text/css">
body {
	font-family:verdana,arial,sans-serif;
	font-size:10pt;
	margin:10px;
	background-color:#000;
	}
</style>
</head>
<body>
<h3>Bienvenue</h3>

<style>#web-buttons-idhb635 a{display:block;color:transparent;} #web-buttons-idhb635 a:hover{background-position:left bottom;}a#web-buttons-idhb635a {display:none}</style>
<table id="web-buttons-idhb635" width=0 cellpadding=0 cellspacing=0 border=0><tr>
<td style="padding-right:0px" title ="entrer">
<a href="pass2.php" title="entrer" style="background-image:url(admin-files/bthb635.png);width:100px;height:41px;display:block;"target="content"><br/></a></td>
</tr></table>





</body>
</html>